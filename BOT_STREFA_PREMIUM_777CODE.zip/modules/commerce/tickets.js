const {
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  AttachmentBuilder,
  PermissionsBitField,
  ChannelType,
  MessageFlags,
  EmbedBuilder,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  FileBuilder
} = require('discord.js');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const TICKET_STATS_PATH = path.join(__dirname, '..', '..', 'data', 'ticket_stats.json');
const LEGITCHECK_SOURCE_CHANNEL_ID = process.env.LEGITCHECK_SOURCE_CHANNEL_ID;
const POMOC_CATEGORY_ID = process.env.POMOC_CATEGORY_ID;
const BLAD_CATEGORY_ID = process.env.BLAD_CATEGORY_ID;
const INNE_CATEGORY_ID = process.env.INNE_CATEGORY_ID;
const PACZKI_CATEGORY_ID = process.env.PACZKI_CATEGORY_ID;
const ZAMOWIENIA_CATEGORY_ID = process.env.ZAMOWIENIA_CATEGORY_ID;
const WAZNE_CATEGORY_ID = process.env.WAZNE_CATEGORY_ID;
const TICKET_LOGS_CHANNEL_ID = process.env.TICKET_LOGS_CHANNEL_ID;
const MODERATION_LOG_CHANNEL_ID = process.env.MODERATION_LOG_CHANNEL_ID;
const GLOBAL_ROLE_ID = process.env.GLOBAL_STAFF_ROLE_ID;
const ALL_TICKETS_ROLE_ID = process.env.ALL_TICKETS_ROLE_ID;
const COLLABORATION_ROLE_ID = process.env.COLLABORATION_ROLE_ID;
const SELECT_ARROW_EMOJI_ID = process.env.SELECT_ARROW_EMOJI_ID;
const CLAIMED_NONE = "none";
const ALL_TICKETS_PERMISSIONS = [
  PermissionsBitField.Flags.ViewChannel,
  PermissionsBitField.Flags.SendMessages,
  PermissionsBitField.Flags.SendMessagesInThreads,
  PermissionsBitField.Flags.ReadMessageHistory,
  PermissionsBitField.Flags.AddReactions,
  PermissionsBitField.Flags.AttachFiles,
  PermissionsBitField.Flags.EmbedLinks,
  PermissionsBitField.Flags.MentionEveryone,
  PermissionsBitField.Flags.UseExternalEmojis,
  PermissionsBitField.Flags.UseExternalStickers,
  PermissionsBitField.Flags.CreatePublicThreads,
  PermissionsBitField.Flags.CreatePrivateThreads,
  PermissionsBitField.Flags.UseApplicationCommands,
  PermissionsBitField.Flags.ManageChannels,
  PermissionsBitField.Flags.ManageRoles,
  PermissionsBitField.Flags.ManageMessages,
  PermissionsBitField.Flags.ManageWebhooks,
  PermissionsBitField.Flags.ManageThreads
];

const COLORS = {
  main: 0x5865F2,
  success: 0x57F287,
  error: 0xED4245,
  warn: 0xFEE75C
};

const SELECT_ARROW_EMOJI = {
  id: SELECT_ARROW_EMOJI_ID,
  name: 'strzalka',
  animated: true
};

let ticketStats = {};
try {
  if (fs.existsSync(TICKET_STATS_PATH)) {
    ticketStats = JSON.parse(fs.readFileSync(TICKET_STATS_PATH, 'utf8'));
  }
} catch (error) {
  console.error('Nie udało się wczytać statystyk ticketów:', error);
  throw error;
}

let ticketStatsWriteQueue = Promise.resolve();
const ticketsClosingAfterLegitCheck = new Set();

function saveTicketStats() {
  const snapshot = JSON.stringify(ticketStats, null, 2);
  ticketStatsWriteQueue = ticketStatsWriteQueue.catch(() => {}).then(async () => {
    await fs.promises.mkdir(path.dirname(TICKET_STATS_PATH), { recursive: true });
    const tempPath = `${TICKET_STATS_PATH}.tmp`;
    await fs.promises.writeFile(tempPath, snapshot, 'utf8');
    await fs.promises.rename(tempPath, TICKET_STATS_PATH);
  });
  return ticketStatsWriteQueue;
}

async function recordTicketClosure(guildId, channel, closedByUser) {
  const ticketId = extractTopicValue(channel.topic, 'id') || channel.id;
  if (!ticketStats[guildId]) ticketStats[guildId] = { users: {}, closedTickets: [] };
  const guildStats = ticketStats[guildId];
  if (!guildStats.users) guildStats.users = {};
  if (!guildStats.closedTickets) guildStats.closedTickets = [];
  if (guildStats.closedTickets.includes(ticketId)) return;

  guildStats.closedTickets.push(ticketId);
  guildStats.users[closedByUser.id] = (guildStats.users[closedByUser.id] || 0) + 1;
  await saveTicketStats();
}


function v2Flags(ephemeral = false) {
  return ephemeral
    ? (MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral)
    : MessageFlags.IsComponentsV2;
}

function text(content) {
  return new TextDisplayBuilder().setContent(content);
}

function separator() {
  return new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);
}

function buildContainer({ title, description, color = COLORS.main, banner = false, rows = [], fileNames = [] }) {
  const container = new ContainerBuilder();

  if (banner) {
    container.addMediaGalleryComponents(
      new MediaGalleryBuilder().addItems(
        new MediaGalleryItemBuilder().setURL('attachment://banner.png')
      )
    );
  }

  if (title) container.addTextDisplayComponents(text(`## ${title}`));
  if (title && description) container.addSeparatorComponents(separator());
  if (description) container.addTextDisplayComponents(text(description));

  if (description && fileNames.length > 0) {
    container.addSeparatorComponents(separator());
  }

  for (const name of fileNames) {
    container.addFileComponents(new FileBuilder().setURL(`attachment://${name}`));
  }

  if (rows.length > 0) {
    container.addSeparatorComponents(separator());
    container.addActionRowComponents(...rows);
  }

  return container;
}

function statusContainer(content, color = COLORS.main) {
  return new ContainerBuilder()
    .addTextDisplayComponents(text(content));
}

function statusPayload(content, { color = COLORS.main, ephemeral = false } = {}) {
  return { components: [statusContainer(content, color)], flags: v2Flags(ephemeral) };
}

const errorReply = (content) => statusPayload(content, { color: COLORS.error, ephemeral: true });
const warnReply = (content) => statusPayload(content, { color: COLORS.warn, ephemeral: true });
const successReply = (content, ephemeral = true) => statusPayload(content, { color: COLORS.success, ephemeral });


function getBannerUpload() {
  const bannerPath = path.join(__dirname, '..', '..', 'banner.png');
  if (fs.existsSync(bannerPath)) {
    return new AttachmentBuilder(bannerPath, { name: 'banner.png' });
  }
  return null;
}

function extractTopicValue(topic, key) {
  if (!topic) return null;
  for (const part of topic.split(";")) {
    const keyValue = part.split("=");
    if (keyValue.length === 2 && keyValue[0] === key) return keyValue[1];
  }
  return null;
}

function setTopicValue(topic, key, value) {
  const topicParts = (topic || '')
    .split(";")
    .filter(part => part && !part.startsWith(`${key}=`));
  topicParts.push(`${key}=${value}`);
  return topicParts.join(";");
}

function buildTicketTopic(baseName, claimedById, ticketId, creatorId) {
  return `base=${baseName};claimed=${claimedById ? claimedById : CLAIMED_NONE};id=${ticketId};creator=${creatorId}`;
}

function generateTicketId() {
  const hex = crypto.randomBytes(4).toString('hex').toUpperCase().substring(0, 7);
  return `TICKET-${hex}`;
}

function sanitizeChannelName(input) {
  if (!input) return "";
  return input.toLowerCase().trim()
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9\-_]/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

function sanitizeChannelPart(input) {
  let sanitized = input.toLowerCase().replace(/[^a-z0-9\-_]/g, "-").replace(/-+/g, "-");
  if (sanitized.startsWith("-")) sanitized = sanitized.substring(1);
  if (sanitized.endsWith("-")) sanitized = sanitized.substring(0, sanitized.length - 1);
  return sanitized;
}

function getOrderName(value) {
  switch (value) {
    case "paczka_pluginow": return "Paczka Pluginów";
    case "konfiguracja_serwera": return "Konfiguracja Serwera";
    case "plugin": return "Plugin";
    case "bot_discord": return "Bot Discord";
    case "strona_www": return "Strona WWW";
    case "grafika": return "Grafika";
    case "texturepack": return "TexturePack";
    case "mapa": return "Mapa";
    case "montaz": return "Montaż";
    case "skrypt": return "Skrypt";
    default: return "Nieznane zamówienie";
  }
}

function getCategoryId(categoryName) {
  switch (categoryName) {
    case "pomoc": return POMOC_CATEGORY_ID;
    case "blad": return BLAD_CATEGORY_ID;
    case "inne": return INNE_CATEGORY_ID;
    case "paczki": return PACZKI_CATEGORY_ID;
    case "zamowienia": return ZAMOWIENIA_CATEGORY_ID;
    case "wazne": return WAZNE_CATEGORY_ID;
    case "nagroda": return INNE_CATEGORY_ID;
    case "wspolpraca": return INNE_CATEGORY_ID;
    case "zamowienie": return ZAMOWIENIA_CATEGORY_ID;
    default: return null;
  }
}

function getChannelPrefix(categoryName, subCategory) {
  if (categoryName === "pomoc") return "🔎・pomoc";
  if (categoryName === "blad") return "🔧・blad";
  if (categoryName === "inne") return "📁・inne";
  if (categoryName === "wspolpraca") return "🤝・wspolpraca";
  if (categoryName === "paczki") return "📦・paczki";
  if (categoryName === "wazne") return "⭐・wazne";
  if (categoryName === "nagroda") return "🎁・nagroda";

  if (categoryName === "zamowienie" || categoryName === "zamowienia") {
    switch (subCategory) {
      case "Paczka Pluginów": return "📦・paczka";
      case "Konfiguracja Serwera": return "⚙️・konfiguracja";
      case "Plugin": return "🔌・plugin";
      case "Bot Discord": return "🤖・bot";
      case "Strona WWW": return "🌐・strona";
      case "Grafika": return "🎨・grafika";
      case "TexturePack": return "🖼️・texturepack";
      case "Mapa": return "🗺️・mapa";
      case "Montaż": return "🎬・montaz";
      case "Skrypt": return "📜・skrypt";
      default: return "🛒・zamowienie";
    }
  }
  return "🎫・ticket";
}

function getRoleIdForTicket(categoryName, subCategory) {
  if (categoryName === "pomoc") return process.env.POMOC_ROLE_ID;
  if (categoryName === "blad") return process.env.BLAD_ROLE_ID;
  if (categoryName === "wspolpraca") return COLLABORATION_ROLE_ID;
  if (categoryName === "inne") return process.env.INNE_ROLE_ID;

  if (categoryName === "zamowienie" || categoryName === "zamowienia") {
    switch (subCategory) {
      case "Strona WWW": return process.env.STRONA_WWW_ROLE_ID;
      case "TexturePack": return process.env.TEXTUREPACK_ROLE_ID;
      case "Skrypt": return process.env.SKRYPT_ROLE_ID;
      case "Bot Discord": return process.env.BOT_DISCORD_ROLE_ID;
      case "Grafika": return process.env.GRAFIKA_ROLE_ID;
      case "Paczka Pluginów": return process.env.PACZKA_ROLE_ID;
      case "Konfiguracja Serwera": return process.env.PACZKA_ROLE_ID;
      case "Mapa": return process.env.MAPA_ROLE_ID;
      case "Montaż": return process.env.MONTAZ_ROLE_ID;
      case "Plugin": return process.env.PLUGIN_ROLE_ID;
      default: return null;
    }
  }
  return null;
}

function hasStaffTicketAccess(member, channel) {
  if (member.permissions.has(PermissionsBitField.Flags.Administrator) || member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
    return true;
  }
  if (member.roles.cache.has(ALL_TICKETS_ROLE_ID)) {
    return true;
  }
  const creatorId = extractTopicValue(channel.topic, "creator");
  if (creatorId && creatorId === member.id) {
    return false;
  }
  if (member.roles.cache.has(GLOBAL_ROLE_ID)) {
    return true;
  }
  return channel.permissionOverwrites.cache.some(override =>
    override.type === 0 && member.roles.cache.has(override.id) && override.allow.has(PermissionsBitField.Flags.ViewChannel)
  );
}

module.exports = {
  name: 'ticketCommandListener',

  async onClientReady(client) {
    for (const guild of client.guilds.cache.values()) {
      let channels;
      try {
        channels = await guild.channels.fetch();
      } catch (error) {
        console.error(`Nie udało się pobrać ticketów serwera ${guild.id} do nadania dostępu roli ${ALL_TICKETS_ROLE_ID}:`, error);
        continue;
      }

      for (const channel of channels.values()) {
        if (channel?.type !== ChannelType.GuildText || !extractTopicValue(channel.topic, 'creator')) continue;
        try {
          await channel.permissionOverwrites.edit(ALL_TICKETS_ROLE_ID, {
            ViewChannel: true,
            SendMessages: true,
            ReadMessageHistory: true,
            SendMessagesInThreads: true,
            AddReactions: true,
            AttachFiles: true,
            EmbedLinks: true,
            MentionEveryone: true,
            UseExternalEmojis: true,
            UseExternalStickers: true,
            CreatePublicThreads: true,
            CreatePrivateThreads: true,
            UseApplicationCommands: true,
            ManageChannels: true,
            ManageRoles: true,
            ManageMessages: true,
            ManageWebhooks: true,
            ManageThreads: true
          }, { reason: 'Rola z pełnym dostępem do ticketów' });
        } catch (error) {
          console.error(`Nie udało się nadać roli ${ALL_TICKETS_ROLE_ID} dostępu do ticketa ${channel.id}:`, error);
        }

        if (
          COLLABORATION_ROLE_ID &&
          INNE_CATEGORY_ID &&
          channel.parentId === INNE_CATEGORY_ID &&
          channel.name.startsWith('🤝')
        ) {
          try {
            await channel.permissionOverwrites.edit(COLLABORATION_ROLE_ID, {
              ViewChannel: true,
              SendMessages: true,
              ReadMessageHistory: true
            }, { reason: 'Dostęp roli współpracy do ticketu współpracy' });
          } catch (error) {
            console.error(`Nie udało się nadać roli współpracy ${COLLABORATION_ROLE_ID} dostępu do ticketa ${channel.id}:`, error);
          }
        }
      }
    }
  },

  async onMessageCreate(message) {
    if (
      message.author.bot ||
      !message.guild ||
      message.channel.id !== LEGITCHECK_SOURCE_CHANNEL_ID ||
      !/^\+rep\b/i.test(message.content.trim())
    ) {
      return;
    }

    const findTicket = channels => channels
      .filter(channel =>
        channel.type === ChannelType.GuildText &&
        (extractTopicValue(channel.topic, 'repBuyer') === message.author.id ||
          extractTopicValue(channel.topic, 'creator') === message.author.id)
      )
      .sort((first, second) => {
        const firstIsLinked = extractTopicValue(first.topic, 'repBuyer') === message.author.id;
        const secondIsLinked = extractTopicValue(second.topic, 'repBuyer') === message.author.id;
        if (firstIsLinked !== secondIsLinked) return firstIsLinked ? -1 : 1;
        return second.createdTimestamp - first.createdTimestamp;
      })
      .first();
    let ticket = findTicket(message.guild.channels.cache);
    if (!ticket) {
      try {
        const fetchedChannels = await message.guild.channels.fetch();
        ticket = findTicket(fetchedChannels);
      } catch (error) {
        console.error(`Nie udało się pobrać kanałów serwera przy obsłudze legit checka ${message.id}:`, error);
        return;
      }
    }

    if (!ticket) {
      console.warn(`Nie znaleziono otwartego ticketa dla autora legit checka ${message.author.id}.`);
      return;
    }
    if (ticketsClosingAfterLegitCheck.has(ticket.id)) return;
    ticketsClosingAfterLegitCheck.add(ticket.id);

    const reason = 'Użytkownik wystawił legit check po realizacji zamówienia.';
    setTimeout(async () => {
      try {
        await ticket.delete('Legit check wystawiony po realizacji zamówienia');
      } catch (error) {
        console.error(`Nie udało się automatycznie zamknąć ticketa ${ticket.id}:`, error);
      } finally {
        ticketsClosingAfterLegitCheck.delete(ticket.id);
      }
    }, 5000);

    try {
      await ticket.send({
        components: [
          buildContainer({
            title: 'LEGIT CHECK WYSTAWIONY',
            description:
              `Dziękujemy <@${message.author.id}> za wystawienie legit checka.\n` +
              `Zamówienie uznajemy za zrealizowane, dlatego ticket zostanie zamknięty za 5 sekund.\n` +
              `**Powód zamknięcia:** ${reason}`
          })
        ],
        flags: v2Flags(),
        allowedMentions: { parse: [] }
      });
    } catch (error) {
      console.error(`Nie udało się powiadomić o automatycznym zamknięciu ticketa ${ticket.id}:`, error);
    }

    try {
      await recordTicketClosure(message.guild.id, ticket, message.client.user);
    } catch (error) {
      console.error(`Nie udało się zapisać statystyki automatycznego zamknięcia ticketa ${ticket.id}:`, error);
    }

    try {
      await this.sendTicketClosedLogs(message.guild, ticket, message.client.user, reason);
    } catch (error) {
      console.error(`Nie udało się zapisać logów automatycznego zamknięcia ticketa ${ticket.id}:`, error);
    }
  },

  async onSlashCommandInteraction(interaction) {
    const { commandName } = interaction;

    if (commandName === 'ticket_panel') return this.handleTicketPanelCommand(interaction);
    if (commandName === 'adduser') return this.handleAddUserCommand(interaction);
    if (commandName === 'removeuser') return this.handleRemoveUserCommand(interaction);
    if (commandName === 'zamknij') return this.handleZamknijCommand(interaction);
    if (commandName === 'wezwij') return this.handleWezwijCommand(interaction);
    if (commandName === 'przejmij' || commandName === 'odprzejmij') {
      const { channel, member } = interaction;
      if (channel.type !== ChannelType.GuildText || !channel.topic?.includes('creator=')) {
        return interaction.reply(errorReply('❌ Tej komendy można używać wyłącznie na kanałach ticketów!'));
      }
      if (!member || !hasStaffTicketAccess(member, channel)) {
        return interaction.reply(errorReply('❌ Nie masz uprawnień do zarządzania tym ticketem!'));
      }
      return commandName === 'przejmij'
        ? this.handleZajmijTicket(interaction)
        : this.handleZwolnijTicket(interaction);
    }
    if (commandName === 'statystyki') return this.handleTicketStats(interaction);
  },

  async handleTicketStats(interaction) {
    if (!interaction.member?.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return interaction.reply(errorReply('❌ Tylko administrator może wyświetlić statystyki ticketów.'));
    }

    const guildStats = ticketStats[interaction.guildId];
    const entries = Object.entries(guildStats?.users || {})
      .filter(([, count]) => count > 0)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 25);

    const description = entries.length
      ? entries.map(([userId, count], index) => `**${index + 1}.** <@${userId}> — **${count}** zamkniętych ticketów`).join('\n')
      : 'Brak zapisanych zamkniętych ticketów.';

    return interaction.reply({
      components: [new ContainerBuilder().addTextDisplayComponents(
        text(`## STATYSTYKI ZAMKNIĘTYCH TICKETÓW\n\n${description}`)
      )],
      flags: v2Flags(true),
      allowedMentions: { parse: [] }
    });
  },

  async handleTicketPanelCommand(interaction) {
    if (!interaction.member || !interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return interaction.reply(errorReply("❌ Nie posiadasz uprawnień do użycia tej komendy!"));
    }

    const ticketMenu = new StringSelectMenuBuilder()
      .setCustomId('ticket:kategoria')
      .setPlaceholder('Wybierz kategorię zgłoszenia')
      .setMinValues(1)
      .setMaxValues(1)
      .addOptions([
        { label: 'Zamówienie', value: 'zamowienie', description: 'Jeśli chcesz coś zamówić, wybierz tę opcję!', emoji: SELECT_ARROW_EMOJI },
        { label: 'Pomoc', value: 'pomoc', description: 'Jeśli potrzebujesz pomocy, wybierz tę opcję!', emoji: SELECT_ARROW_EMOJI },
        { label: 'Błąd', value: 'blad', description: 'Jeśli znalazłeś błąd, wybierz tę opcję!', emoji: SELECT_ARROW_EMOJI },
        { label: 'Odbiór nagrody', value: 'nagroda', description: 'Jeśli wygrałeś nagrodę, wybierz tę opcję!', emoji: SELECT_ARROW_EMOJI },
        { label: 'Współpraca', value: 'wspolpraca', description: 'Jeśli chcesz nawiązać współpracę, wybierz tę opcję!', emoji: SELECT_ARROW_EMOJI }
      ]);

    const row = new ActionRowBuilder().addComponents(ticketMenu);
    const banner = getBannerUpload();

    const container = buildContainer({
      title: "CENTRUM POMOCY",
      description:
        "> Masz pytanie, chcesz złożyć zamówienie lub zgłosić błąd?\n" +
        "> Wybierz odpowiednią kategorię z poniższego menu rozwijanego,\n" +
        "> aby utworzyć prywatny kanał i skontaktować się z administracją.\n\n" +
        "> Pamiętaj, że administracja ma również swoje życie\n" +
        "> prywatne, maksymalny czas na sprawdzenie ticketa to **48h**!\n\n" +
        "> Zabroniony jest spam i bezsensowne tickety. Grozi to **permamentnym banem** na discordzie.",
      banner: !!banner,
      rows: [row]
    });

    await interaction.channel.send({
      components: [container],
      files: banner ? [banner] : [],
      flags: v2Flags()
    });

    await interaction.reply(successReply("✅ Panel ticketów został pomyślnie wysłany!"));
  },

  async handleAddUserCommand(interaction) {
    const { channel, member } = interaction;
    if (channel.type !== ChannelType.GuildText) {
      return interaction.reply(errorReply("❌ Tej komendy można używać tylko na kanałach tekstowych!"));
    }

    if (!channel.topic || !channel.topic.includes("creator=")) {
      return interaction.reply(errorReply("❌ Tej komendy można używać wyłącznie na kanałach ticketów!"));
    }

    if (!member || !hasStaffTicketAccess(member, channel)) {
      return interaction.reply(errorReply("❌ Nie posiadasz uprawnień do dodawania osób do tego ticketa!"));
    }

    const targetUser = interaction.options.getMember('user');
    if (!targetUser) {
      return interaction.reply(errorReply("❌ Nie znaleziono podanego użytkownika na serwerze!"));
    }

    await channel.permissionOverwrites.edit(targetUser.id, {
      ViewChannel: true,
      SendMessages: true
    });

    await interaction.reply(successReply(`✅ Pomyślnie dodano użytkownika <@${targetUser.id}> do tego ticketa.`, false));
  },

  async handleRemoveUserCommand(interaction) {
    const { channel, member } = interaction;
    if (channel.type !== ChannelType.GuildText) {
      return interaction.reply(errorReply("❌ Tej komendy można używać tylko na kanałach tekstowych!"));
    }

    if (!channel.topic || !channel.topic.includes("creator=")) {
      return interaction.reply(errorReply("❌ Tej komendy można używać wyłącznie na kanałach ticketów!"));
    }

    if (!member || !hasStaffTicketAccess(member, channel)) {
      return interaction.reply(errorReply("❌ Nie posiadasz uprawnień do usuwania osób z tego ticketa!"));
    }

    const targetUser = interaction.options.getMember('user');
    if (!targetUser) {
      return interaction.reply(errorReply("❌ Nie znaleziono podanego użytkownika na serwerze!"));
    }

    await channel.permissionOverwrites.delete(targetUser.id);
    await interaction.reply(successReply(`✅ Pomyślnie usunięto dostęp do ticketa użytkownikowi <@${targetUser.id}>.`, false));
  },

  async handleWezwijCommand(interaction) {
    const { channel, member, guild, user } = interaction;
    if (channel.type !== ChannelType.GuildText) {
      return interaction.reply(errorReply("❌ Tej komendy można używać tylko na kanałach tekstowych!"));
    }

    const creatorId = extractTopicValue(channel.topic, "creator");
    if (!creatorId) {
      return interaction.reply(errorReply("❌ Tej komendy można używać wyłącznie na kanałach ticketów!"));
    }

    if (!member || !hasStaffTicketAccess(member, channel)) {
      return interaction.reply(errorReply("❌ Nie posiadasz uprawnień do wezwania użytkownika na ticket!"));
    }

    if (creatorId === user.id) {
      return interaction.reply(errorReply("❌ Nie możesz wezwać samego siebie na ticket!"));
    }

    let creator;
    try {
      creator = await interaction.client.users.fetch(creatorId);
      await creator.send({
        components: [
          statusContainer(
            `## WEZWANIE\n` +
            `Jesteś wzywany przez administrację na ticket na serwerze **${guild.name}**.\n` +
            `Jeśli **nie odpowiesz** w ciągu __24 godzin__, ticket zostanie zamknięty.\n\n` +
            `**Ticket:** <#${channel.id}>\n`
          )
        ],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
    } catch (error) {
      console.error(`Nie udało się wysłać wezwania DM do użytkownika ${creatorId}:`, error);
      return interaction.reply(errorReply("❌ Nie udało się wysłać wiadomości prywatnej. Użytkownik może mieć zablokowane wiadomości od serwera."));
    }

    try {
      if (!MODERATION_LOG_CHANNEL_ID) {
        throw new Error('Brak MODERATION_LOG_CHANNEL_ID w pliku .env.');
      }

      const logChannel = guild.channels.cache.get(MODERATION_LOG_CHANNEL_ID)
        || await guild.channels.fetch(MODERATION_LOG_CHANNEL_ID);
      if (!logChannel?.isTextBased() || typeof logChannel.send !== 'function') {
        throw new Error(`Kanał logów ${MODERATION_LOG_CHANNEL_ID} nie jest kanałem tekstowym.`);
      }

      const logEmbed = new EmbedBuilder()
        .setColor(COLORS.warn)
        .setTitle('Wezwano użytkownika na ticket')
        .addFields(
          { name: 'Administrator', value: `<@${user.id}> (\`${user.id}\`)` },
          { name: 'Wezwany użytkownik', value: `<@${creator.id}> (\`${creator.id}\`)` },
          { name: 'Ticket', value: `<#${channel.id}> (\`${channel.id}\`)` }
        )
        .setTimestamp();

      await logChannel.send({ embeds: [logEmbed], allowedMentions: { parse: [] } });
    } catch (error) {
      console.error('Nie udało się zapisać wezwania użytkownika w logach:', error);
    }

    await interaction.reply(successReply(`✅ Pomyślnie wezwano: <@${creatorId}>`));
  },

  async handleZamknijCommand(interaction) {
    const { channel, member, guild, user } = interaction;
    if (channel.type !== ChannelType.GuildText) {
      return interaction.reply(errorReply("❌ Tej komendy można używać tylko na kanałach tekstowych!"));
    }

    if (!channel.topic || !channel.topic.includes("creator=")) {
      return interaction.reply(errorReply("❌ Tej komendy można używać wyłącznie na kanałach ticketów!"));
    }

    if (!member || !hasStaffTicketAccess(member, channel)) {
      return interaction.reply(errorReply("❌ Nie posiadasz uprawnień do zamknięcia tego ticketa!"));
    }

    const claimedById = extractTopicValue(channel.topic, "claimed");
    if (claimedById && claimedById !== CLAIMED_NONE && claimedById !== user.id) {
      return interaction.reply(
        warnReply(`⚠️ Ten ticket jest zajęty przez <@${claimedById}>. Tylko ta osoba może go teraz zamknąć — poczekaj, aż zwolni ticket.`)
      );
    }

    const reason = "Zamknięte komendą /zamknij";
    try {
      await recordTicketClosure(guild.id, channel, user);
    } catch (error) {
      console.error('Nie udało się zapisać statystyki zamknięcia ticketa:', error);
      return interaction.reply(errorReply('❌ Nie udało się zapisać statystyki. Ticket nie został zamknięty; spróbuj ponownie.'));
    }
    await interaction.reply(
      statusPayload(`🔒 Ticket zostanie **usunięty za 5 sekund** przez <@${user.id}>`, { color: COLORS.warn })
    );

    await this.sendTicketClosedLogs(guild, channel, user, reason);

    setTimeout(() => {
      channel.delete().catch(() => {});
    }, 5000);
  },

  async onStringSelectInteraction(interaction) {
    const { customId, guild, member, channel, user, values } = interaction;
    if (!guild || !member) return;

    if (customId === "ticket:zmien_kategorie_select") {
      if (!hasStaffTicketAccess(member, channel)) {
        return interaction.reply(errorReply("❌ Nie masz uprawnień do zarządzania tym ticketem!"));
      }

      const categoryId = values[0];
      if (!categoryId || ![
        POMOC_CATEGORY_ID,
        BLAD_CATEGORY_ID,
        INNE_CATEGORY_ID,
        PACZKI_CATEGORY_ID,
        ZAMOWIENIA_CATEGORY_ID,
        WAZNE_CATEGORY_ID
      ].includes(categoryId)) {
        return interaction.reply(errorReply("❌ Wybrana kategoria nie znajduje się na liście kategorii ticketów."));
      }

      let targetCategory;
      try {
        targetCategory = guild.channels.cache.get(categoryId) || await guild.channels.fetch(categoryId);
      } catch (error) {
        console.error(`Nie udało się pobrać kategorii ${categoryId} dla ticketa ${channel.id}:`, error);
        return interaction.reply(errorReply("❌ Nie udało się pobrać wybranej kategorii. Sprawdź, czy bot ma dostęp do kanałów."));
      }
      if (!targetCategory || targetCategory.type !== ChannelType.GuildCategory) {
        return interaction.reply(errorReply("❌ Nie znaleziono wybranej kategorii na serwerze!"));
      }

      if (channel.parentId === targetCategory.id) {
        return interaction.reply(warnReply(`⚠️ Ticket już znajduje się w kategorii **${targetCategory.name}**.`));
      }

      await interaction.deferReply({ flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 });
      try {
        await channel.setParent(targetCategory.id, {
          lockPermissions: false,
          reason: `Przeniesienie ticketu przez ${user.tag}`
        });
        return interaction.editReply(successReply(`✅ Ticket został pomyślnie przeniesiony do kategorii: **${targetCategory.name}**`));
      } catch (error) {
        console.error(`Nie udało się przenieść ticketa ${channel.id} do kategorii ${targetCategory.id}:`, error);
        return interaction.editReply(errorReply("❌ Nie udało się przenieść ticketa. Sprawdź uprawnienie „Zarządzanie kanałami” bota oraz uprawnienia do kategorii."));
      }
    }

    if (customId === "ticket:kategoria") {
      const selectedValue = values[0];

      if (selectedValue === "zamowienie") {
        const orderSelect = new StringSelectMenuBuilder()
          .setCustomId('ticket:zamowienie')
          .setPlaceholder('🛒 Wybierz rodzaj zamówienia')
          .setMinValues(1)
          .setMaxValues(1)
          .addOptions([
            { label: 'Paczka', value: 'paczka_pluginow', description: 'Gotowa paczka pluginów dopasowana do Twojego serwera.', emoji: SELECT_ARROW_EMOJI },
            { label: 'Konfiguracja Serwera', value: 'konfiguracja_serwera', description: 'Profesjonalna konfiguracja i przygotowanie serwera.', emoji: SELECT_ARROW_EMOJI },
            { label: 'Plugin', value: 'plugin', description: 'Indywidualny plugin stworzony według Twojego pomysłu.', emoji: SELECT_ARROW_EMOJI },
            { label: 'Bot Discord', value: 'bot_discord', description: 'Własny bot Discord z funkcjami dopasowanymi do Twoich potrzeb.', emoji: SELECT_ARROW_EMOJI },
            { label: 'Strona WWW', value: 'strona_www', description: 'Nowoczesna i responsywna strona internetowa.', emoji: SELECT_ARROW_EMOJI },
            { label: 'Grafika', value: 'grafika', description: 'Logo, baner, avatar lub inny projekt graficzny.', emoji: SELECT_ARROW_EMOJI },
            { label: 'TexturePack', value: 'texturepack', description: 'Unikalny texturepack przygotowany dla Twojego serwera.', emoji: SELECT_ARROW_EMOJI },
            { label: 'Mapa', value: 'mapa', description: 'Indywidualna mapa Minecraft stworzona według Twojej wizji.', emoji: SELECT_ARROW_EMOJI },
            { label: 'Montaż', value: 'montaz', description: 'Profesjonalny montaż filmów i materiałów promocyjnych.', emoji: SELECT_ARROW_EMOJI },
            { label: 'Skrypt', value: 'skrypt', description: 'Skrypt wykonujący dokładnie to, czego potrzebujesz.', emoji: SELECT_ARROW_EMOJI }
          ]);

        const row = new ActionRowBuilder().addComponents(orderSelect);

        const container = buildContainer({
          title: "CENTRUM POMOCY - ZAMÓWIENIA",
          description: "Wybierz usługę, którą jesteś zainteresowany.\nPo wybraniu odpowiedniej opcji zostanie utworzony ticket.",
          rows: [row]
        });

        return interaction.reply({ components: [container], flags: v2Flags(true) });
      }

      return this.createTicket(guild, member, selectedValue, "Brak (Ogólne)", interaction);
    }

    if (customId === "ticket:zamowienie") {
      const selectedOrder = values[0];
      return this.createTicket(guild, member, "zamowienie", getOrderName(selectedOrder), interaction);
    }

    if (customId === "ticket:zamknij_select") {
      if (!hasStaffTicketAccess(member, channel)) {
        return interaction.reply(errorReply("❌ Nie masz uprawnień do zamknięcia tego ticketu!"));
      }

      const reason = values[0];
      const claimedById = extractTopicValue(channel.topic, "claimed");

      if (claimedById && claimedById !== CLAIMED_NONE && claimedById !== user.id) {
        return interaction.reply(
          warnReply(`⚠️ Ten ticket jest zajęty przez <@${claimedById}>. Tylko ta osoba może go teraz zamknąć — poczekaj, aż zwolni ticket.`)
        );
      }

      if (reason === "Inny powód") {
        const reasonInput = new TextInputBuilder()
          .setCustomId("ticket:inny_powod_input")
          .setLabel("Powód zamknięcia")
          .setPlaceholder("Wpisz własny powód zamknięcia ticketa...")
          .setStyle(TextInputStyle.Short)
          .setMaxLength(100)
          .setRequired(true);

        const modal = new ModalBuilder()
          .setCustomId("ticket:inny_powod_modal")
          .setTitle("Podaj powód zamknięcia")
          .addComponents(new ActionRowBuilder().addComponents(reasonInput));

        return interaction.showModal(modal);
      }

      try {
        await recordTicketClosure(guild.id, channel, user);
      } catch (error) {
        console.error('Nie udało się zapisać statystyki zamknięcia ticketa:', error);
        return interaction.reply(errorReply('❌ Nie udało się zapisać statystyki. Ticket nie został zamknięty; spróbuj ponownie.'));
      }

      await interaction.reply(
        statusPayload(
          `🔒 Ticket zostanie **usunięty za 5 sekund** przez <@${user.id}>\n**Powód:** \`${reason}\``,
          { color: COLORS.warn }
        )
      );

      await this.sendTicketClosedLogs(guild, channel, user, reason);

      setTimeout(() => {
        channel.delete().catch(() => {});
      }, 5000);
    }
  },

  async onModalInteraction(interaction) {
    const { customId, channel, member, guild, user } = interaction;

    if (customId === "ticket:zmien_nazwe_modal") {
      return this.handleZmienNazweModal(interaction);
    }

    if (customId === "ticket:inny_powod_modal") {
      if (!member || !hasStaffTicketAccess(member, channel)) {
        return interaction.reply(errorReply("❌ Nie masz uprawnień do tego ticketu!"));
      }

      const customReason = interaction.fields.getTextInputValue("ticket:inny_powod_input");
      const claimedById = extractTopicValue(channel.topic, "claimed");

      if (claimedById && claimedById !== CLAIMED_NONE && claimedById !== user.id) {
        return interaction.reply(
          warnReply(`⚠️ Ten ticket jest zajęty przez <@${claimedById}>. Tylko ta osoba może go teraz zamknąć — poczekaj, aż zwolni ticket.`)
        );
      }

      try {
        await recordTicketClosure(guild.id, channel, user);
      } catch (error) {
        console.error('Nie udało się zapisać statystyki zamknięcia ticketa:', error);
        return interaction.reply(errorReply('❌ Nie udało się zapisać statystyki. Ticket nie został zamknięty; spróbuj ponownie.'));
      }

      await interaction.reply(
        statusPayload(
          `🔒 Ticket zostanie **usunięty za 5 sekund** przez <@${user.id}>\n**Powód:** \`${customReason}\``,
          { color: COLORS.warn }
        )
      );

      await this.sendTicketClosedLogs(guild, channel, user, customReason);

      setTimeout(() => {
        channel.delete().catch(() => {});
      }, 5000);
    }
  },

  async createTicket(guild, member, categoryName, subCategory, interaction) {
    const categoryId = getCategoryId(categoryName);
    if (!categoryId) {
      return interaction.reply(errorReply("❌ Nie znaleziono kategorii dla tego ticketu!"));
    }

    const channelPrefix = getChannelPrefix(categoryName, subCategory);
    const channelName = `${channelPrefix}-${member.user.username}`;
    const ticketId = generateTicketId();
    const ticketTopic = buildTicketTopic(channelName, null, ticketId, member.id);
    const specificRoleId = getRoleIdForTicket(categoryName, subCategory);

    const permissionOverwrites = [
      {
        id: guild.roles.everyone.id,
        deny: [PermissionsBitField.Flags.ViewChannel]
      },
      {
        id: member.id,
        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages]
      }
    ];

    for (const roleId of new Set([GLOBAL_ROLE_ID, ALL_TICKETS_ROLE_ID].filter(Boolean))) {
      permissionOverwrites.push({
        id: roleId,
        allow: roleId === ALL_TICKETS_ROLE_ID
          ? ALL_TICKETS_PERMISSIONS
          : [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages]
      });
    }

    if (specificRoleId) {
      permissionOverwrites.push({
        id: specificRoleId,
        allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages]
      });
    }

    try {
      const channel = await guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: categoryId,
        topic: ticketTopic,
        permissionOverwrites: permissionOverwrites
      });

      const btnZajmij = new ButtonBuilder().setCustomId("ticket:zajmij").setLabel("Zajmij ticket").setStyle(ButtonStyle.Success);
      const btnZwolnij = new ButtonBuilder().setCustomId("ticket:zwolnij").setLabel("Zwolnij ticket").setStyle(ButtonStyle.Danger);
      const btnNazwa = new ButtonBuilder().setCustomId("ticket:zmien_nazwe").setLabel("Zmień nazwę").setStyle(ButtonStyle.Secondary);
      const btnKategoria = new ButtonBuilder().setCustomId("ticket:zmien_kategorie").setLabel("Zmień kategorię").setStyle(ButtonStyle.Secondary);

      const rowButtons = new ActionRowBuilder().addComponents(btnZajmij, btnZwolnij, btnNazwa, btnKategoria);

      const closeMenu = new StringSelectMenuBuilder()
        .setCustomId("ticket:zamknij_select")
        .setPlaceholder("Aby zamknąć ticket kliknij tutaj")
        .setMinValues(1)
        .setMaxValues(1)
        .addOptions([
          { label: "Sprawa rozwiązana", value: "Sprawa rozwiązana", description: "Problem zgłaszającego został rozwiązany" },
          { label: "Brak odpowiedzi", value: "Brak odpowiedzi", description: "Zgłaszający nie odpowiada od dłuższego czasu" },
          { label: "Odpowiedź uzyskana", value: "Odpowiedź uzyskana", description: "Udzielono potrzebnej odpowiedzi" },
          { label: "Nadane", value: "Nadane", description: "Usługa została nadana" },
          { label: "Nie aktualne", value: "Nie aktualne", description: "Zgłoszenie straciło aktualność" },
          { label: "Inny powód", value: "Inny powód", description: "Inny powód" }
        ]);

      const rowMenu = new ActionRowBuilder().addComponents(closeMenu);
      const banner = getBannerUpload();

      const container = buildContainer({
        title: "CENTRUM POMOCY",
        description:
          `Witaj <@${member.id}>, Opisz szczegółowo swoje zgłoszenie.\n` +
          `Administracja zajmie się nim jak najszybciej.\n\n` +
          `**Ważne zasady:**\n> Nie pinguj zarządu ani developerów\n> Zachowaj kulturę przez całą rozmowę\n` +
          `> Opisz szczegółowo swój problem/zamówienie\n> Czas odpowiedzi: **do 48 godzin**`,
        banner: !!banner,
        rows: [rowButtons, rowMenu]
      });

      let ping = `<@${member.id}>`;
      if (specificRoleId) ping += ` <@&${specificRoleId}>`;
      else if (GLOBAL_ROLE_ID) ping += ` <@&${GLOBAL_ROLE_ID}>`;

      await channel.send({
        components: [text(ping), container],
        files: banner ? [banner] : [],
        flags: v2Flags()
      });

      await interaction.reply(successReply(`✅ Twój ticket został utworzony: <#${channel.id}>`));

    } catch (err) {
      console.error(err);
      await interaction.reply(errorReply("❌ Błąd podczas tworzenia kanału ticketu."));
    }
  },

  async onButtonInteraction(interaction) {
    const { channel, member, customId } = interaction;
    if (!customId || !customId.startsWith('ticket:')) return;

    if (!member || !hasStaffTicketAccess(member, channel)) {
      return interaction.reply(errorReply("❌ Tylko administracja i osoby uprawnione mogą korzystać z tego przycisku!"));
    }

    if (customId === "ticket:zajmij") return this.handleZajmijTicket(interaction);
    if (customId === "ticket:zwolnij") return this.handleZwolnijTicket(interaction);
    if (customId === "ticket:zmien_nazwe") return this.handleZmienNazwe(interaction);
    if (customId === "ticket:zmien_kategorie") return this.handleZmienKategorie(interaction);
  },

  async handleZmienKategorie(interaction) {
    const configuredCategories = [
      { label: "Pomoc", value: POMOC_CATEGORY_ID, description: "Przenieś ticket do kategorii Pomoc" },
      { label: "Błąd", value: BLAD_CATEGORY_ID, description: "Przenieś ticket do kategorii Błąd" },
      { label: "Inne", value: INNE_CATEGORY_ID, description: "Przenieś ticket do kategorii Inne" },
      { label: "Zamówienia", value: ZAMOWIENIA_CATEGORY_ID, description: "Przenieś ticket do kategorii Zamówienia" },
      { label: "Paczki", value: PACZKI_CATEGORY_ID, description: "Przenieś ticket do kategorii Paczki" },
      { label: "Ważne", value: WAZNE_CATEGORY_ID, description: "Przenieś ticket do kategorii Ważne" }
    ].filter(category => category.value);

    if (configuredCategories.length === 0) {
      return interaction.reply(errorReply("❌ Nie skonfigurowano żadnych kategorii ticketów."));
    }

    const categorySelect = new StringSelectMenuBuilder()
      .setCustomId("ticket:zmien_kategorie_select")
      .setPlaceholder("Wybierz nową kategorię dla ticketu")
      .setMinValues(1)
      .setMaxValues(1)
      .addOptions(configuredCategories);

    const row = new ActionRowBuilder().addComponents(categorySelect);

    const container = buildContainer({
      description: "### Wybierz docelową kategorię:",
      rows: [row]
    });

    await interaction.reply({ components: [container], flags: v2Flags(true) });
  },

  async handleZmienNazwe(interaction) {
    const nameInput = new TextInputBuilder()
      .setCustomId("ticket:nowa_nazwa_input")
      .setLabel("Nowa nazwa kanału")
      .setValue(interaction.channel.name)
      .setStyle(TextInputStyle.Short)
      .setMinLength(1)
      .setMaxLength(100)
      .setRequired(true);

    const modal = new ModalBuilder()
      .setCustomId("ticket:zmien_nazwe_modal")
      .setTitle("Zmień nazwę kanału")
      .addComponents(new ActionRowBuilder().addComponents(nameInput));

    await interaction.showModal(modal);
  },

  async handleZmienNazweModal(interaction) {
    const channel = interaction.channel;
    if (!interaction.member || !hasStaffTicketAccess(interaction.member, channel)) {
      return interaction.reply(errorReply("❌ Nie masz uprawnień do zmiany nazwy tego kanału."));
    }

    const inputName = interaction.fields.getTextInputValue("ticket:nowa_nazwa_input");
    let newName = sanitizeChannelName(inputName);

    if (!newName) {
      return interaction.reply(errorReply("❌ Nazwa kanału nie może być pusta."));
    }
    if (newName.length > 100) newName = newName.substring(0, 100);

    if (channel.name === newName) {
      return interaction.reply(statusPayload(`ℹ️ Kanał już posiada nazwę **\`${newName}\`**.`, { ephemeral: true }));
    }

    await channel.setName(newName);
    await interaction.reply(successReply(`✅ Nazwa kanału została zmieniona na **\`${newName}\`**.`));
  },

  async handleZajmijTicket(interaction) {
    const channel = interaction.channel;
    const topic = channel.topic;
    let baseName = extractTopicValue(topic, "base") || channel.name;
    const claimedById = extractTopicValue(topic, "claimed");

    if (claimedById && claimedById !== CLAIMED_NONE) {
      const msg = claimedById === interaction.user.id
        ? "⚠️ Ty już zająłeś ten ticket."
        : `⚠️ Ten ticket jest już zajęty przez <@${claimedById}>. Poczekaj, aż go zwolni, zanim przejmiesz zgłoszenie.`;
      return interaction.reply(warnReply(msg));
    }

    const ticketId = extractTopicValue(topic, "id");
    const creatorId = extractTopicValue(topic, "creator");
    const adminNick = sanitizeChannelPart(interaction.user.username);
    const newChannelName = `${baseName}-${adminNick}`;
    const newTopic = buildTicketTopic(baseName, interaction.user.id, ticketId, creatorId);

    const container = buildContainer({
      title: "Ticket Przejęty",
      description:
        `**Zajął:** <@${interaction.user.id}>\n` +
        `Ticket został przejęty przez administratora, on udzieli Ci dalszej pomocy!`,
      color: COLORS.success
    });

    await interaction.reply({ components: [container], flags: v2Flags() });
    await channel.setName(newChannelName);
    await channel.setTopic(newTopic);
  },

  async handleZwolnijTicket(interaction) {
    const channel = interaction.channel;
    const topic = channel.topic;
    let baseName = extractTopicValue(topic, "base") || channel.name;
    const claimedById = extractTopicValue(topic, "claimed");

    if (!claimedById || claimedById === CLAIMED_NONE) {
      return interaction.reply(warnReply("⚠️ Ten ticket nie jest obecnie przez nikogo zajęty."));
    }

    if (claimedById !== interaction.user.id) {
      return interaction.reply(warnReply(`⚠️ Ten ticket jest zajęty przez <@${claimedById}>. Tylko ta osoba może go zwolnić.`));
    }

    const ticketId = extractTopicValue(topic, "id");
    const creatorId = extractTopicValue(topic, "creator");
    const newTopic = buildTicketTopic(baseName, null, ticketId, creatorId);

    const container = buildContainer({
      title: "Ticket Zwolniony",
      description:
        `**Zwolnił:** <@${interaction.user.id}>\n` +
        `Ticket jest teraz dostępny dla pozostałej administracji.`,
      color: COLORS.warn
    });

    await interaction.reply({ components: [container], flags: v2Flags() });
    await channel.setName(baseName);
    await channel.setTopic(newTopic);
  },

  async sendTicketClosedLogs(guild, channel, closedByUser, reason) {
    if (!guild) return;

    const topic = channel.topic;
    const creatorId = extractTopicValue(topic, "creator");
    const cleanChannelName = channel.name.replace(/^[^\na-zA-Z0-9]+/, "").replace(/・/g, "");
    const rawReason = (!reason || reason.trim().length === 0) ? "Brak" : reason;

    const openedBy = creatorId ? creatorId : "Brak danych";
    const closedBy = `${closedByUser.username} (ID:${closedByUser.id})`;
    const logText =
      `Logi ticketu: ${cleanChannelName}\n` +
      `Otwarty przez (ID): ${openedBy}\n` +
      `Zamknięty przez: ${closedBy}\n` +
      `Powód: ${rawReason}\n`;

    const staffFileName = `log-${cleanChannelName}.txt`;
    const staffLogFile = new AttachmentBuilder(Buffer.from(logText, 'utf-8'), { name: staffFileName });
    const logsChannel = guild.channels.cache.get(TICKET_LOGS_CHANNEL_ID);

    if (logsChannel) {
      const banner = getBannerUpload();
      const files = [staffLogFile];
      if (banner) files.push(banner);

      const container = buildContainer({
        title: "CENTRUM POMOCY - LOGI",
        description:
          `> Zgłoszenie **${cleanChannelName}** zostało zamknięte przez <@${closedByUser.id}>.\n` +
          `> Powód zamknięcia: **${rawReason}**\n\n` +
          `> Poniżej znajdziesz plik z zapisem zgłoszenia \`${staffFileName}\``,
        banner: !!banner,
        fileNames: [staffFileName],
        color: COLORS.error
      });

      await logsChannel.send({ components: [container], files, flags: v2Flags() }).catch(() => {});
    }

    if (creatorId) {
      try {
        const creatorMember = await guild.members.fetch(creatorId);
        const userFileName = `Twoja-Transkrypcja-${cleanChannelName}.txt`;
        const userLogFile = new AttachmentBuilder(Buffer.from(logText, 'utf-8'), { name: userFileName });
        const banner = getBannerUpload();
        const files = [userLogFile];
        if (banner) files.push(banner);

        const container = buildContainer({
          title: "CENTRUM POMOCY - ZGŁOSZENIE ZAMKNIĘTE",
          description:
            `> Hej, <@${creatorMember.id}>! Twoje zgłoszenie zostało zamknięte przez <@${closedByUser.id}>.\n` +
            `> Powód: **${rawReason}**\n\n` +
            `> Jeśli uważasz, że Twoja sprawa nie została w pełni rozwiązana, możesz w każdej chwili utworzyć nowe zgłoszenie.\n\n` +
            `> Poniżej znajdziesz plik z zapisem Twojego zgłoszenia \`${userFileName}\``,
          banner: !!banner,
          fileNames: [userFileName],
          color: COLORS.error
        });

        await creatorMember.send({ components: [container], files, flags: v2Flags() }).catch(() => {});
      } catch (err) {}
    }
  }
};
