const {
  ContainerBuilder,
  MessageFlags,
  SeparatorBuilder,
  SeparatorSpacingSize,
  TextDisplayBuilder
} = require('discord.js');
const fs = require('fs');
const path = require('path');

const SOURCE_CHANNEL_ID = process.env.LEGITCHECK_SOURCE_CHANNEL_ID;
const COUNTER_PATH = path.join(__dirname, '..', '..', 'legitcheck.json');

let submissionQueue = Promise.resolve();
let guideMessageId = null;

function separator() {
  return new SeparatorBuilder()
    .setDivider(true)
    .setSpacing(SeparatorSpacingSize.Small);
}

function parseRepMessage(content) {
  return /^\+rep\b/i.test(content.trim());
}

async function readLegitCheckCount() {
  let contents;
  try {
    contents = await fs.promises.readFile(COUNTER_PATH, 'utf8');
  } catch (error) {
    if (error.code === 'ENOENT') return 0;
    throw error;
  }

  if (!contents.trim()) return 0;

  const stored = JSON.parse(contents);
  if (!stored || !Number.isSafeInteger(stored.count) || stored.count < 0) {
    throw new Error('legitcheck.json must contain a non-negative integer count.');
  }
  return stored.count;
}

async function saveLegitCheckCount(count) {
  await fs.promises.mkdir(path.dirname(COUNTER_PATH), { recursive: true });
  const temporaryPath = `${COUNTER_PATH}.tmp`;
  await fs.promises.writeFile(temporaryPath, JSON.stringify({ count }, null, 2), 'utf8');
  await fs.promises.rename(temporaryPath, COUNTER_PATH);
}

function buildLegitCheckContainer() {
  return new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        '# TwojSerwer × JAK WYSTAWIĆ LEGIT CHECKA?'
      )
    )
    .addSeparatorComponents(separator())
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        '• Jeżeli otrzymałeś swoje zamówienie, prosimy o wystawienie legit checka.\n' +
        '• Powinien być on napisany w podanej formie:\n' +
        '```+rep [@Użytkownik] [Produkt]```\n' +
        '• **Przykładowo:**\n' +
        '```+rep @machel28 PACZKA ANA FFA```'
      )
    )
    .addSeparatorComponents(separator())
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent('💚 © 2026 TwojSerwer')
    );
}

async function findPreviousGuide(channel, botUserId) {
  if (!channel.messages?.fetch) return null;

  try {
    const recentMessages = await channel.messages.fetch({ limit: 50 });
    return recentMessages.find(candidate =>
      candidate.author.id === botUserId &&
      candidate.components?.some(component =>
        component.components?.some(child =>
          child.content?.includes('JAK WYSTAWIĆ LEGIT CHECKA?')
        )
      )
    ) || null;
  } catch (error) {
    console.error('Nie udało się znaleźć poprzedniego poradnika legit check:', error);
    return null;
  }
}

async function replacePreviousGuide(channel, botUserId) {
  let previousGuide = null;

  if (guideMessageId) {
    try {
      previousGuide = await channel.messages.fetch(guideMessageId);
    } catch (error) {
      if (error.code !== 10008) {
        console.error('Nie udało się pobrać poprzedniego poradnika legit check:', error);
      }
    }
  } else {
    previousGuide = await findPreviousGuide(channel, botUserId);
  }

  guideMessageId = null;
  if (!previousGuide) return;

  try {
    await previousGuide.delete();
  } catch (error) {
    console.error('Nie udało się usunąć poprzedniego poradnika legit check:', error);
  }
}

async function notifyFailure(message, failures) {
  if (failures.length === 0) return;

  const uniqueFailures = [...new Set(failures)];
  try {
    await message.reply({
      content: `Nie udało się wykonać wszystkich działań dla tego legit checka:\n${uniqueFailures.map(failure => `• ${failure}`).join('\n')}`,
      allowedMentions: { repliedUser: false }
    });
  } catch (error) {
    console.error('Nie udało się wysłać informacji o błędach legit checka:', error);
  }
}

function updateLegitCheck(message) {
  const submission = submissionQueue.then(async () => {
    const channel = message.channel;
    const failures = [];
    const nextCount = (await readLegitCheckCount()) + 1;
    await saveLegitCheckCount(nextCount);

    try {
      await message.react('💚');
    } catch (error) {
      console.error(`[legitCheck] Nie udało się dodać 💚 do wiadomości ${message.id}:`, error);
      failures.push('Nie udało się dodać reakcji 💚. Sprawdź uprawnienia „Dodawanie reakcji” i „Czytanie historii wiadomości” dla bota na tym kanale.');
    }

    if (typeof channel.setName === 'function') {
      const currentName = /^(.*?)(?:-(\d+))?$/.exec(channel.name || '');
      const channelBaseName = currentName[1] || channel.name || 'legit-check';
      const nextName = `${channelBaseName}-${nextCount}`;

      try {
        await channel.setName(nextName);
      } catch (error) {
        console.error(`[legitCheck] Nie udało się zmienić nazwy kanału na „${nextName}”:`, error);
        failures.push(`Nie udało się zmienić nazwy kanału na „${nextName}”. Sprawdź uprawnienie „Zarządzanie kanałami” dla bota.`);
      }
    } else {
      failures.push('Ten kanał nie obsługuje zmiany nazwy (np. wątek).');
    }

    if (typeof channel.send === 'function') {
      await replacePreviousGuide(channel, message.client.user.id);

      try {
        const guideMessage = await channel.send({
          components: [buildLegitCheckContainer()],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
        guideMessageId = guideMessage.id;
      } catch (error) {
        console.error('[legitCheck] Nie udało się wysłać poradnika legit check:', error);
        failures.push('Nie udało się wysłać poradnika legit check.');
      }
    }

    await notifyFailure(message, failures);
  });

  submissionQueue = submission.catch(() => {});
  return submission;
}

module.exports = {
  name: 'legitCheckEventListener',

  async onMessageCreate(message) {
    if (message.author.bot || message.channel.id !== SOURCE_CHANNEL_ID) return;
    if (!parseRepMessage(message.content)) return;

    try {
      await updateLegitCheck(message);
    } catch (error) {
      console.error('Nie udało się obsłużyć legit checka:', error);
      await notifyFailure(message, ['Wystąpił nieoczekiwany błąd. Sprawdź konsolę bota.']);
    }
  }
};
