const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  AttachmentBuilder,
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SectionBuilder,
  ThumbnailBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder
} = require('discord.js');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const COOLDOWN_MS = 4 * 60 * 60 * 1000;
const MAX_LISTED_REWARDS = 25;

const PREMIUM_ROLE_ID = process.env.DROP_PREMIUM_ROLE_ID;

const WIN_BANNER_FILE = 'drop_win.png';
const LOSE_BANNER_FILE = 'drop_lose.png';

const WIN_COLOR = 0x2BFF3A;

const DROPS = {
  standardowy: {
    title: 'DROP STANDARD',
    rewards: [
      { name: 'Rabat -5%', chance: 0.05, roleId: process.env.DROP_RABAT_5_ROLE_ID },
      { name: 'Rabat -10%', chance: 0.03, roleId: process.env.DROP_RABAT_10_ROLE_ID },
      { name: 'Strefa Premium', chance: 0.01, roleId: process.env.DROP_STREFA_PREMIUM_ROLE_ID }
    ]
  },
  premium: {
    title: 'DROP PREMIUM',
    rewards: [
      { name: 'Rabat -15%', chance: 0.05, roleId: process.env.DROP_RABAT_15_ROLE_ID },
      { name: 'Rabat -20%', chance: 0.03, roleId: process.env.DROP_RABAT_20_ROLE_ID }
    ]
  }
};

const COMMAND_TO_TYPE = {
  drop_standard: 'standardowy',
  drop_premium: 'premium'
};

const DATA_PATH = path.join(__dirname, '..', '..', 'data', 'drops.json');

let store = { cooldowns: {}, rewards: {} };

try {
  if (fs.existsSync(DATA_PATH)) {
    const loaded = JSON.parse(fs.readFileSync(DATA_PATH, 'utf-8'));
    store = { cooldowns: loaded.cooldowns || {}, rewards: loaded.rewards || {} };
  }
} catch (err) {
  console.error('Nie udało się wczytać drops.json: ' + err.message);
}

let writeChain = Promise.resolve();
function saveStore() {
  const snapshot = JSON.stringify(store);
  writeChain = writeChain
    .then(async () => {
      const tmp = DATA_PATH + '.tmp';
      await fs.promises.writeFile(tmp, snapshot, 'utf-8');
      await fs.promises.rename(tmp, DATA_PATH);
    })
    .catch(err => console.error('Nie udało się zapisać drops.json: ' + err.message));
  return writeChain;
}

function v2Flags(ephemeral = false) {
  return ephemeral
    ? (MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral)
    : MessageFlags.IsComponentsV2;
}

const text = (content) => new TextDisplayBuilder().setContent(content);
const sep = () => new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);

function statusReply(content, color) {
  const container = new ContainerBuilder().addTextDisplayComponents(text(content));
  return { components: [container], flags: v2Flags(true), allowedMentions: { parse: [] } };
}

const errorReply = (content) => statusReply(content, 0xED4245);
const warnReply = (content) => statusReply(content, 0xFEE75C);

function avatarOf(user) {
  return user.displayAvatarURL({ extension: 'png', size: 256 });
}

function bannerAttachment(fileName) {
  const filePath = path.join(__dirname, '..', '..', fileName);
  if (fs.existsSync(filePath)) {
    return new AttachmentBuilder(filePath, { name: fileName });
  }
  return null;
}

function rollReward(rewards) {
  const roll = crypto.randomInt(1_000_000) / 1_000_000;
  let cursor = 0;
  for (const reward of rewards) {
    cursor += reward.chance;
    if (roll < cursor) return reward;
  }
  return null;
}

function buildResultPayload({ type, user, won, reward, readyAt, roleGranted = false, roleFailed = false }) {
  const cfg = DROPS[type];
  const bannerFile = won ? WIN_BANNER_FILE : LOSE_BANNER_FILE;
  const banner = bannerAttachment(bannerFile);

  const container = new ContainerBuilder();

  container
    .addTextDisplayComponents(text(`## ${cfg.title}`))
    .addSeparatorComponents(sep());

  const body = won
    ? `> Gratulacje, <@${user.id}> ✅ !\n> Twoja wygrana: **${reward.name}**` +
      (roleGranted ? `\n> Rola <@&${reward.roleId}> została właśnie nadana!` : '') +
      (roleFailed ? `\n> ⚠️ Nie udało się nadać roli automatycznie — zgłoś się do administracji.` : '')
    : `> Niestety, <@${user.id}>. Tym razem Ci się nie udało!\n` +
      `> Kolejny raz możesz spróbować za: <t:${Math.floor(readyAt / 1000)}:R>`;

  container.addSectionComponents(
    new SectionBuilder()
      .addTextDisplayComponents(text(body))
      .setThumbnailAccessory(new ThumbnailBuilder().setURL(avatarOf(user)))
  );

  const commandName = type === 'premium' ? '/drop_premium' : '/drop_standard';
  container.addTextDisplayComponents(text(`> Chcesz też spróbować? Wpisz \`${commandName}\`!`));

  if (banner) {
    container.addMediaGalleryComponents(
      new MediaGalleryBuilder().addItems(
        new MediaGalleryItemBuilder().setURL(`attachment://${bannerFile}`)
      )
    );
  }

  const retryBtn = new ButtonBuilder()
    .setCustomId(`drop:retry:${type}`)
    .setLabel('Spróbuj ponownie')
    .setStyle(ButtonStyle.Secondary);

  const rewardsBtn = new ButtonBuilder()
    .setCustomId(`drop:rewards:${type}`)
    .setLabel('Sprawdź swoje nagrody')
    .setStyle(ButtonStyle.Secondary);

  container
    .addSeparatorComponents(sep())
    .addActionRowComponents(new ActionRowBuilder().addComponents(retryBtn, rewardsBtn));

  return {
    components: [container],
    files: banner ? [banner] : [],
    flags: v2Flags(),
    allowedMentions: { parse: [] }
  };
}

async function runDrop(interaction, type) {
  const cfg = DROPS[type];
  const { user, member } = interaction;

  if (type === 'premium' && PREMIUM_ROLE_ID && !(member && member.roles.cache.has(PREMIUM_ROLE_ID))) {
    return interaction.reply(errorReply(`❌ Ten drop jest dostępny tylko dla posiadaczy roli <@&${PREMIUM_ROLE_ID}>.`));
  }

  const key = `${type}:${user.id}`;
  const now = Date.now();
  const readyAtStored = store.cooldowns[key] || 0;

  if (readyAtStored > now) {
    return interaction.reply(
      warnReply(`**${cfg.title}** — możesz spróbować ponownie <t:${Math.floor(readyAtStored / 1000)}:R>.`)
    );
  }

  const readyAt = now + COOLDOWN_MS;
  store.cooldowns[key] = readyAt;

  const reward = rollReward(cfg.rewards);
  const won = reward !== null;
  let roleGranted = false;
  let roleFailed = false;

  if (won) {
    if (!store.rewards[user.id]) store.rewards[user.id] = [];
    store.rewards[user.id].push({ type, name: reward.name, ts: now });

    if (reward.roleId && member) {
      try {
        await member.roles.add(reward.roleId, `Wygrana w ${cfg.title}`);
        roleGranted = true;
      } catch (err) {
        roleFailed = true;
        console.error(`Nie udało się nadać roli ${reward.roleId} użytkownikowi ${user.id}:`, err);
      }
    }
  }

  saveStore();

  return interaction.reply(buildResultPayload({ type, user, won, reward, readyAt, roleGranted, roleFailed }));
}

async function showRewards(interaction, type) {
  const cfg = DROPS[type];
  const { user } = interaction;

  const all = (store.rewards[user.id] || []).filter(r => r.type === type);
  const hidden = Math.max(0, all.length - MAX_LISTED_REWARDS);
  const shown = all.slice(hidden);

  let body;
  if (all.length === 0) {
    body = '> Nie masz jeszcze żadnych wygranych.';
  } else {
    body = shown
      .map((r, i) => `> ${hidden + i + 1}. **${r.name}** - <t:${Math.floor(r.ts / 1000)}:d>`)
      .join('\n');
    if (hidden > 0) body += `\n> *…oraz ${hidden} starszych wygranych*`;
  }

  const container = new ContainerBuilder()
    .addTextDisplayComponents(text(`## ${cfg.title} - Twoje wygrane`))
    .addSeparatorComponents(sep())
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(text(body))
        .setThumbnailAccessory(new ThumbnailBuilder().setURL(avatarOf(user)))
    );

  return interaction.reply({
    components: [container],
    flags: v2Flags(true),
    allowedMentions: { parse: [] }
  });
}

module.exports = {
  name: 'dropEventListener',

  async onSlashCommandInteraction(interaction) {
    const type = COMMAND_TO_TYPE[interaction.commandName];
    if (!type) return;

    return runDrop(interaction, type);
  },

  async onButtonInteraction(interaction) {
    const [namespace, action, type] = interaction.customId.split(':');
    if (namespace !== 'drop' || !DROPS[type]) return;

    if (action === 'retry') return runDrop(interaction, type);
    if (action === 'rewards') return showRewards(interaction, type);
  }
};
