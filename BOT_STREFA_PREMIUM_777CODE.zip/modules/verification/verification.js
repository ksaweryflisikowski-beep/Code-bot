const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  AttachmentBuilder,
  PermissionsBitField,
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder
} = require('discord.js');
const path = require('path');
const fs = require('fs');

const VERIFIED_ROLE_ID = process.env.VERIFIED_ROLE_ID;

const COLORS = {
  main: 0x5865F2,
  success: 0x57F287,
  error: 0xED4245,
  warn: 0xFEE75C
};


function v2Flags(ephemeral = false) {
  return ephemeral
    ? (MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral)
    : MessageFlags.IsComponentsV2;
}

function text(content) {
  return new TextDisplayBuilder().setContent(content);
}

function separator() {
  return new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);
}

function buildContainer({ title, description, color = COLORS.main, banner = false, rows = [] }) {
  const container = new ContainerBuilder();

  if (banner) {
    container.addMediaGalleryComponents(
      new MediaGalleryBuilder().addItems(
        new MediaGalleryItemBuilder().setURL('attachment://banner.png')
      )
    );
  }

  if (title) container.addTextDisplayComponents(text(`## ${title}`));
  if (title && description) container.addSeparatorComponents(separator());
  if (description) container.addTextDisplayComponents(text(description));

  if (rows.length > 0) {
    container.addSeparatorComponents(separator());
    container.addActionRowComponents(...rows);
  }

  return container;
}

function statusPayload(content, { color = COLORS.main, ephemeral = false } = {}) {
  const container = new ContainerBuilder()
    .addTextDisplayComponents(text(content));
  return { components: [container], flags: v2Flags(ephemeral) };
}

const errorReply = (content) => statusPayload(content, { color: COLORS.error, ephemeral: true });
const warnReply = (content) => statusPayload(content, { color: COLORS.warn, ephemeral: true });
const successReply = (content) => statusPayload(content, { color: COLORS.success, ephemeral: true });


function getBannerUpload() {
  const bannerPath = path.join(__dirname, '..', '..', 'banner.png');
  if (fs.existsSync(bannerPath)) {
    return new AttachmentBuilder(bannerPath, { name: 'banner.png' });
  }
  return null;
}

module.exports = {
  name: 'verificationCommandListener',

  async onSlashCommandInteraction(interaction) {
    if (interaction.commandName !== 'weryfikacja_panel') return;

    if (!interaction.member || !interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return interaction.reply(errorReply("❌ Nie posiadasz uprawnień do użycia tej komendy!"));
    }

    const verifyButton = new ButtonBuilder()
      .setCustomId("weryfikacja:potwierdz")
      .setLabel("✅ Rozpocznij Weryfikację")
      .setStyle(ButtonStyle.Success);

    const row = new ActionRowBuilder().addComponents(verifyButton);
    const banner = getBannerUpload();

    const container = buildContainer({
      title: "WERYFIKACJA",
      description:
        "Witaj na serwerze **TwojSerwer**!\n\n" +
        "Aby uzyskać pełny dostęp do reszty kanałów oraz społeczności,\n" +
        "musisz przejść proces weryfikacji.\n\n" +
        "Kliknij poniższy przycisk **Rozpocznij Weryfikację**, aby rozwiązać proste zadanie.",
      banner: !!banner,
      rows: [row]
    });

    await interaction.channel.send({
      components: [container],
      files: banner ? [banner] : [],
      flags: v2Flags()
    });

    await interaction.reply(successReply("✅ Panel weryfikacji został pomyślnie wysłany!"));
  },

  async onButtonInteraction(interaction) {
    if (interaction.customId !== 'weryfikacja:potwierdz') return;

    const { guild, member } = interaction;
    if (!guild || !member) {
      return interaction.reply(errorReply("❌ Wystąpił błąd podczas pobierania danych serwera."));
    }

    if (member.roles.cache.has(VERIFIED_ROLE_ID)) {
      return interaction.reply(warnReply("Jesteś już **zweryfikowany** na tym serwerze!"));
    }

    const isAddition = Math.random() < 0.5;
    let num1, num2, expectedResult;

    if (isAddition) {
      num1 = Math.floor(Math.random() * 11);
      num2 = Math.floor(Math.random() * (21 - num1));
      expectedResult = num1 + num2;
    } else {
      num1 = Math.floor(Math.random() * 21);
      num2 = Math.floor(Math.random() * (num1 + 1));
      expectedResult = num1 - num2;
    }

    const mathQuestion = `${num1}${isAddition ? " + " : " - "}${num2}`;

    const mathInput = new TextInputBuilder()
      .setCustomId("weryfikacja:odpowiedz")
      .setLabel(`Ile to jest ${mathQuestion}?`)
      .setPlaceholder("np. 10")
      .setStyle(TextInputStyle.Short)
      .setMinLength(1)
      .setMaxLength(2)
      .setRequired(true);

    const modal = new ModalBuilder()
      .setCustomId(`weryfikacja:modal:${expectedResult}`)
      .setTitle("Weryfikacja Matematyczna")
      .addComponents(new ActionRowBuilder().addComponents(mathInput));

    await interaction.showModal(modal);
  },

  async onModalInteraction(interaction) {
    if (!interaction.customId.startsWith("weryfikacja:modal:")) return;

    const expectedAnswer = interaction.customId.replace("weryfikacja:modal:", "");
    const userAnswer = interaction.fields.getTextInputValue("weryfikacja:odpowiedz")
      ? interaction.fields.getTextInputValue("weryfikacja:odpowiedz").trim()
      : "";

    const { guild, member } = interaction;
    if (!guild || !member) {
      return interaction.reply(errorReply("❌ Wystąpił błąd podczas pobierania danych serwera."));
    }

    if (userAnswer !== expectedAnswer) {
      return interaction.reply(errorReply("❌ Błędna odpowiedź! Spróbuj ponownie klikając przycisk weryfikacji."));
    }

    const verifiedRole = guild.roles.cache.get(VERIFIED_ROLE_ID);
    if (!verifiedRole) {
      return interaction.reply(errorReply("❌ Rola weryfikacji nie została znaleziona! Skontaktuj się z administracją."));
    }

    try {
      await member.roles.add(verifiedRole);
      await interaction.reply(successReply(`✅ Pomyślnie zostałeś zweryfikowany! Przyznano Ci rolę <@&${verifiedRole.id}>.`));
    } catch (error) {
      await interaction.reply(errorReply("❌ Nie udało się nadać roli. Upewnij się, że rola bota jest wyżej w hierarchii serwera."));
    }
  }
};
