const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  PermissionsBitField,
  MessageFlags,
  ComponentType,
  ContainerBuilder,
  TextDisplayBuilder,
  SectionBuilder,
  ThumbnailBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder
} = require('discord.js');

const SOURCE_CHANNEL_ID = process.env.SCREENSHOT_SOURCE_CHANNEL_ID;
const TARGET_CHANNEL_ID = process.env.SCREENSHOT_TARGET_CHANNEL_ID;
const ROLE_ID = process.env.VERIFIED_ROLE_ID;

const BTN_ACCEPT_PREFIX = "ssv_accept";
const BTN_REJECT_PREFIX = "ssv_reject";
const MODAL_REJECT_PREFIX = "ssv_reject_modal";
const MODAL_REJECT_REASON_ID = "reason";

const COLORS = {
  main: 0x5865F2,
  success: 0x57F287,
  error: 0xED4245,
  warn: 0xFEE75C
};


function v2Flags(ephemeral = false) {
  return ephemeral
    ? (MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral)
    : MessageFlags.IsComponentsV2;
}

function separator() {
  return new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);
}

function statusPayload(content, { color = COLORS.main, ephemeral = false } = {}) {
  const container = new ContainerBuilder()
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(content));
  return { components: [container], flags: v2Flags(ephemeral) };
}

function decisionDmPayload({
  accepted,
  reviewerName,
  recipientName,
  recipientAvatarUrl,
  guildName,
  roleName,
  reason
}) {
  const color = accepted ? COLORS.success : COLORS.error;
  const timestamp = Math.floor(Date.now() / 1000);
  const decisionLabel = accepted ? '✅ DOSTĘP NADANY' : '❌ DOSTĘP ODRZUCONY';
  const decisionText = accepted
    ? 'Twoje zgłoszenie zostało pomyślnie zweryfikowane.'
    : 'Twoje zgłoszenie nie spełniło wymagań weryfikacji.';
  const reasonBlock = String(reason || 'Nie podano powodu.')
    .split('\n')
    .map(line => `> ${line}`)
    .join('\n');
  const accessDetails = accepted
    ? `Otrzymałeś rolę **${roleName || 'Strefa darmowa'}**. Kanały dostępowe są już odblokowane.`
    : `**Powód odrzucenia:**\n${reasonBlock}`;
  const nextStep = accepted
    ? 'Miłego korzystania ze strefy. Jeśli coś nie działa, skontaktuj się z administracją.'
    : 'Popraw zgłoszenie zgodnie z powodem powyżej, a następnie wyślij nowy screenshot na kanale weryfikacji.';

  const container = new ContainerBuilder()
    .setAccentColor(color)
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent('## 777CODE.PL × Dostęp\n### Weryfikacja dostępu')
        )
        .setThumbnailAccessory(new ThumbnailBuilder().setURL(recipientAvatarUrl))
    )
    .addSeparatorComponents(separator())
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(
      `> ## ${decisionLabel}\n> ${decisionText}`
    ))
    .addSeparatorComponents(separator())
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(
      `### Szczegóły decyzji\n` +
      `**Serwer:** ${guildName}\n` +
      `**Użytkownik:** ${recipientName}\n` +
      `**Decyzję podjął(a):** ${reviewerName}\n` +
      `**Data decyzji:** <t:${timestamp}:F>`
    ))
    .addSeparatorComponents(separator())
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(
      `### ${accepted ? 'Dostęp aktywny' : 'Szczegóły odrzucenia'}\n${accessDetails}`
    ))
    .addSeparatorComponents(separator())
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`### Co dalej?\n${nextStep}`));

  return { components: [container], flags: MessageFlags.IsComponentsV2 };
}

function annotatePanel(originalMessage, color, reviewerId, recipientId, userAvatarUrl, reason) {
  const isAccepted = color === COLORS.success;
  const heading = isAccepted ? '## DOSTĘP NADANY' : '## DOSTĘP ODRZUCONY';
  const resultMessage = isAccepted
    ? `> Użytkownik <@${recipientId}> pomyślnie\n> otrzymał dostęp do strefy darmowej!`
    : `> Użytkownik <@${recipientId}> nie\n> otrzymał dostępu do strefy darmowej!`;
  const details = isAccepted
    ? `**Dostęp nadał:**  **Użytkownik:**\n<@${reviewerId}>  <@${recipientId}>`
    : `**Dostęp odrzucił:** **Użytkownik:** **Powód:**\n<@${reviewerId}>  <@${recipientId}> ${reason}`;

  const container = new ContainerBuilder()
    .setAccentColor(color)
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(`${heading}\n${resultMessage}`))
        .setThumbnailAccessory(new ThumbnailBuilder().setURL(userAvatarUrl))
    )
    .addSeparatorComponents(separator())
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(details));

  const mediaAbovePanel = originalMessage.components
    .filter(c => c.type !== ComponentType.Container)
    .map(c => c.toJSON());

  return { components: [...mediaAbovePanel, container], flags: MessageFlags.IsComponentsV2 };
}


function formatDate(date) {
  const pad = (n) => n.toString().padStart(2, '0');
  return `${pad(date.getDate())}.${pad(date.getMonth() + 1)}.${date.getFullYear()} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

module.exports = {
  name: 'screenShotVerificationEventListener',

  async onMessageCreate(message) {
    if (message.author.bot || message.channel.id !== SOURCE_CHANNEL_ID) return;

    const images = message.attachments.filter(att => att.contentType && att.contentType.startsWith('image/'));
    if (images.size === 0) return;

    const targetChannel = message.guild.channels.cache.get(TARGET_CHANNEL_ID);
    if (!targetChannel) {
      console.error("Nie znaleziono kanału docelowego: " + TARGET_CHANNEL_ID);
      return;
    }

    const acceptBtn = new ButtonBuilder()
      .setCustomId(`${BTN_ACCEPT_PREFIX}:${message.author.id}:${message.id}`)
      .setLabel("✅ Zaakceptuj")
      .setStyle(ButtonStyle.Success);

    const rejectBtn = new ButtonBuilder()
      .setCustomId(`${BTN_REJECT_PREFIX}:${message.author.id}:${message.id}`)
      .setLabel("❌ Odrzuć")
      .setStyle(ButtonStyle.Danger);

    const row = new ActionRowBuilder().addComponents(acceptBtn, rejectBtn);

    const gallery = new MediaGalleryBuilder().addItems(
      [...images.values()].slice(0, 10).map(att => new MediaGalleryItemBuilder().setURL(att.url))
    );

    const container = new ContainerBuilder()
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `## TwojSerwer - DOSTĘP\n` +
              `**Użytkownik:** <@${message.author.id}>\n` +
              `**Data zgłoszenia:** ${formatDate(message.createdAt)}`
            )
          )
          .setThumbnailAccessory(new ThumbnailBuilder().setURL(message.author.displayAvatarURL()))
      )
      .addSeparatorComponents(separator())
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          '### Status zgloszenia\n' +
          '**Oczekuje na sprawdzenie przez administracje.**\n' +
          'Uzytkownik nie otrzymal jeszcze dostepu.'
        )
      )
      .addSeparatorComponents(separator())
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          '### Przed podjeciem decyzji\n' +
          '- Sprawdz, czy screenshot jest czytelny i kompletny.\n' +
          '- Zweryfikuj, czy spelnia wymagania dostepu.\n' +
          '- Przy odrzuceniu podaj konkretny powod dla uzytkownika.'
        )
      )
      .addSeparatorComponents(separator())
      .addActionRowComponents(row);

    await targetChannel.send({
      components: [gallery, container],
      flags: MessageFlags.IsComponentsV2
    });
  },

  async onButtonInteraction(interaction) {
    const parts = interaction.customId.split(':');
    if (parts.length !== 3) return;

    const action = parts[0];
    const targetUserId = parts[1];
    const sourceMessageId = parts[2];

    if (action !== BTN_ACCEPT_PREFIX && action !== BTN_REJECT_PREFIX) return;

    const { guild, member } = interaction;
    if (!guild) return;

    if (!member || !member.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return interaction.reply(
        statusPayload("Nie masz uprawnień do wykonania tej akcji.", { color: COLORS.error, ephemeral: true })
      );
    }

    if (action === BTN_ACCEPT_PREFIX) {
      await this.handleAccept(interaction, guild, targetUserId, sourceMessageId);
    } else {
      await this.handleRejectButton(interaction, targetUserId, sourceMessageId);
    }
  },

  async handleAccept(interaction, guild, targetUserId, sourceMessageId) {
    await interaction.deferUpdate();

    try {
      const member = await guild.members.fetch(targetUserId);
      const role = guild.roles.cache.get(ROLE_ID);

      if (role) await member.roles.add(role);

      const nick = member.displayName;

      await this.removeButtonsAndAnnotate(
        interaction,
        COLORS.success,
        interaction.user.id,
        targetUserId,
        member.displayAvatarURL()
      );

      await interaction.followUp(
        statusPayload(`✅ Dostęp do strefy darmowej dla użytkownika **${nick}** został pomyślnie nadany.`, {
          color: COLORS.success,
          ephemeral: true
        })
      );

      await member.send(
        decisionDmPayload({
          accepted: true,
          reviewerName: interaction.user.username,
          recipientName: member.displayName,
          recipientAvatarUrl: member.displayAvatarURL(),
          guildName: guild.name,
          roleName: role?.name
        })
      ).catch(() => {});

    } catch (error) {
      await interaction.followUp(
        statusPayload("⚠️ Wystąpił błąd podczas nadawania roli lub szukania użytkownika: " + error.message, {
          color: COLORS.error,
          ephemeral: true
        })
      );
    }
  },

  async handleRejectButton(interaction, targetUserId, sourceMessageId) {
    const reasonInput = new TextInputBuilder()
      .setCustomId(MODAL_REJECT_REASON_ID)
      .setLabel("Powód odrzucenia")
      .setStyle(TextInputStyle.Paragraph)
      .setPlaceholder("Podaj powód odrzucenia zgłoszenia...")
      .setMinLength(3)
      .setMaxLength(300)
      .setRequired(true);

    const row = new ActionRowBuilder().addComponents(reasonInput);

    const modal = new ModalBuilder()
      .setCustomId(`${MODAL_REJECT_PREFIX}:${targetUserId}:${sourceMessageId}:${interaction.message.id}`)
      .setTitle("Powód odrzucenia")
      .addComponents(row);

    await interaction.showModal(modal);
  },

  async onModalInteraction(interaction) {
    if (!interaction.customId.startsWith(`${MODAL_REJECT_PREFIX}:`)) return;

    const parts = interaction.customId.split(':');
    const targetUserId = parts[1];
    const sourceMessageId = parts[2];
    const panelMessageId = parts[3];

    const reason = interaction.fields.getTextInputValue(MODAL_REJECT_REASON_ID) || "Nie podano powodu.";
    const guild = interaction.guild;
    if (!guild) return;

    await interaction.deferReply({ flags: v2Flags(true) });

    try {
      const member = await guild.members.fetch(targetUserId);
      const nick = member.displayName;

      await this.removeButtonsAndAnnotateById(
        guild,
        panelMessageId,
        COLORS.error,
        interaction.user.id,
        targetUserId,
        member.displayAvatarURL(),
        reason
      );

      await interaction.editReply(
        statusPayload(`❌ Zgłoszenie użytkownika **${nick}** zostało odrzucone.`, { color: COLORS.error })
      );

      await member.send(
        decisionDmPayload({
          accepted: false,
          reviewerName: interaction.user.username,
          recipientName: member.displayName,
          recipientAvatarUrl: member.displayAvatarURL(),
          guildName: guild.name,
          reason
        })
      ).catch(() => {});

    } catch (error) {
      await interaction.editReply(
        statusPayload("⚠️ Nie znaleziono użytkownika na serwerze (mógł go opuścić).", { color: COLORS.warn })
      );
    }
  },

  async removeButtonsAndAnnotate(interaction, color, reviewerId, recipientId, userAvatarUrl) {
    await interaction.editReply(
      annotatePanel(interaction.message, color, reviewerId, recipientId, userAvatarUrl)
    );
  },

  async removeButtonsAndAnnotateById(guild, panelMessageId, color, reviewerId, recipientId, userAvatarUrl, reason) {
    const targetChannel = guild.channels.cache.get(TARGET_CHANNEL_ID);
    if (!targetChannel) return;

    try {
      const original = await targetChannel.messages.fetch(panelMessageId);
      await original.edit(annotatePanel(original, color, reviewerId, recipientId, userAvatarUrl, reason));
    } catch (err) {
      console.error("Nie udało się pobrać panelu do edycji: " + err.message);
    }
  }
};
