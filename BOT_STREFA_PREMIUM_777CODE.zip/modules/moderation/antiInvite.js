const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  AttachmentBuilder,
  PermissionsBitField,
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder
} = require('discord.js');
const path = require('path');
const fs = require('fs');

const LOG_CHANNEL_ID = process.env.ANTI_LINK_LOG_CHANNEL_ID;
const BYPASS_ROLE_ID = process.env.ANTI_LINK_BYPASS_ROLE_ID;
const TIMEOUT_DURATION_MS = 60 * 60 * 1000;
const MAX_PREVIEW_LENGTH = 800;

const LINK_PATTERN = /(https?:\/\/|discord\.gg\/|dc\.gg\/|\b[a-zA-Z0-9.-]+\.(pl|eu|com|net|org|xyz|gg|info|site|online|tech)\b)/i;

const ERROR_COLOR = 0xED4245;

function loadBannerUpload() {
  const bannerPath = path.join(__dirname, '..', '..', 'banner.png');
  if (fs.existsSync(bannerPath)) {
    return new AttachmentBuilder(bannerPath, { name: 'banner.png' });
  }
  return null;
}

function sanitize(content) {
  let safe = content.replace(/`/g, "'");
  if (safe.length > MAX_PREVIEW_LENGTH) {
    safe = safe.substring(0, MAX_PREVIEW_LENGTH) + "… (przycięto)";
  }
  return safe;
}

function escape(text) {
  return text.replace(/\*/g, "\\*").replace(/_/g, "\\_").replace(/`/g, "'");
}

function buildContainer({ title, description, banner = false, rows = [] }) {
  const container = new ContainerBuilder();

  if (banner) {
    container.addMediaGalleryComponents(
      new MediaGalleryBuilder().addItems(
        new MediaGalleryItemBuilder().setURL('attachment://banner.png')
      )
    );
  }

  container
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`## ${title}`))
    .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(description));

  if (rows.length > 0) {
    container
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
      .addActionRowComponents(...rows);
  }

  return container;
}

module.exports = {
  name: 'antiInviteEventListener',

  async onMessageCreate(message) {
    if (!message.guild || message.author.bot || message.webhookId) return;

    const member = message.member;
    if (member && member.permissions.has(PermissionsBitField.Flags.Administrator)) return;
    if (member && BYPASS_ROLE_ID && member.roles.cache.has(BYPASS_ROLE_ID)) return;

    const content = message.content;
    if (!LINK_PATTERN.test(content)) return;

    const author = message.author;
    const guild = message.guild;

    await message.delete().catch(err => console.error("Nie udało się usunąć wiadomości: " + err.message));

    if (member && guild.members.me.permissions.has(PermissionsBitField.Flags.ModerateMembers)) {
      await member.timeout(TIMEOUT_DURATION_MS, "Antyreklama — wysyłanie zabronionych linków")
        .catch(err => console.error("Nie udało się wyciszyć użytkownika: " + err.message));
    }

    await this.notifyAuthor(author, guild, content);
    await this.logIncident(guild, author, `<#${message.channel.id}>`, message.id, content);
  },

  async notifyAuthor(author, guild, content) {
    const banner = loadBannerUpload();

    const container = buildContainer({
      title: "ANTYLINK",
      description:
        `Twoja wiadomość na serwerze **${escape(guild.name)}** została usunięta ze względu na zabronione linki.\n\n` +
        `**Wysłana treść:**\n\`\`\`${sanitize(content)}\`\`\`\n\n` +
        `**Nałożona kara:** Mute na 1h`,
      banner: !!banner
    });

    await author.send({
      components: [container],
      files: banner ? [banner] : [],
      flags: MessageFlags.IsComponentsV2
    }).catch(() => console.log("Nie udało się wysłać pv"));
  },

  async logIncident(guild, author, channelMention, messageId, content) {
    if (!LOG_CHANNEL_ID) return;
    const logChannel = guild.channels.cache.get(LOG_CHANNEL_ID);
    if (!logChannel) return;

    const idButton = new ButtonBuilder()
      .setCustomId(`msg_id_${messageId}`)
      .setLabel(`ID Wiadomości: ${messageId}`)
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(true);

    const row = new ActionRowBuilder().addComponents(idButton);
    const banner = loadBannerUpload();

    const container = buildContainer({
      title: "ANTYLINK",
      description:
        `**Użytkownik:** <@${author.id}>\n` +
        `**ID Użytkownika:** \`${author.id}\`\n` +
        `**Kanał:** ${channelMention}\n\n` +
        `**Treść wiadomości:**\n\`\`\`${sanitize(content)}\`\`\`\n\n` +
        `**Zastosowana kara:** Usunięcie wiadomości + Mute na 1h`,
      banner: !!banner,
      rows: [row]
    });

    await logChannel.send({
      components: [container],
      files: banner ? [banner] : [],
      flags: MessageFlags.IsComponentsV2
    }).catch(err => console.error("Nie udało się wysłać logu: " + err.message));
  }
};
