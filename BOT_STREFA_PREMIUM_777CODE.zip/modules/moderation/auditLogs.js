const {
  AuditLogEvent,
  ContainerBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  MessageFlags,
  SectionBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  ThumbnailBuilder,
  TextDisplayBuilder
} = require('discord.js');

const LOG_CHANNEL_ID = process.env.MODERATION_LOG_CHANNEL_ID;
const BANNER_URL = process.env.BANNER_URL;
const THUMBNAIL_URL = process.env.THUMBNAIL_URL;
const AUDIT_LOG_MAX_AGE_MS = 30_000;

function truncate(value, maxLength = 1000) {
  const text = String(value ?? 'Brak danych');
  return text.length > maxLength ? `${text.slice(0, maxLength - 1)}…` : text;
}

function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function findAuditEntry(guild, type, targetId, channelId, changeKey) {
  await wait(900);

  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      const auditLogs = await guild.fetchAuditLogs({ type, limit: 8 });
      const entry = auditLogs.entries.find(candidate => {
        if (targetId && candidate.targetId !== targetId) return false;
        if (Date.now() - candidate.createdTimestamp > AUDIT_LOG_MAX_AGE_MS) return false;
        if (channelId && candidate.extra?.channel?.id !== channelId) return false;
        if (changeKey && !candidate.changes?.some(change => change.key === changeKey)) return false;
        return true;
      });

      if (entry) return entry;
    } catch (error) {
      console.error(`Nie udało się pobrać dziennika audytu dla serwera ${guild.id}:`, error);
      return null;
    }

    if (attempt < 2) await wait(700);
  }

  return null;
}

function actorField(entry) {
  if (!entry?.executor) return 'Nie udało się ustalić administratora w dzienniku audytu.';
  return `<@${entry.executor.id}>`;
}

async function sendLog(guild, {
  title,
  fields,
  auditEntry
}) {
  if (!LOG_CHANNEL_ID) {
    console.error('Brak MODERATION_LOG_CHANNEL_ID w pliku .env; nie można wysłać logu.');
    return;
  }

  let channel;
  try {
    channel = guild.channels.cache.get(LOG_CHANNEL_ID) || await guild.channels.fetch(LOG_CHANNEL_ID);
  } catch (error) {
    console.error(`Nie udało się pobrać kanału logów ${LOG_CHANNEL_ID}:`, error);
    return;
  }

  if (!channel?.isTextBased() || typeof channel.send !== 'function') {
    console.error(`Kanał logów ${LOG_CHANNEL_ID} nie jest kanałem tekstowym.`);
    return;
  }

  const container = new ContainerBuilder();

  if (BANNER_URL) {
    container.addMediaGalleryComponents(
      new MediaGalleryBuilder().addItems(
        new MediaGalleryItemBuilder().setURL(BANNER_URL)
      )
    );
  }

  const titleDisplay = new TextDisplayBuilder().setContent(`## ${truncate(title, 200)}`);
  if (THUMBNAIL_URL) {
    container.addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(titleDisplay)
        .setThumbnailAccessory(
          new ThumbnailBuilder()
            .setURL(THUMBNAIL_URL)
            .setDescription('Logo serwera')
        )
    );
  } else {
    container.addTextDisplayComponents(titleDisplay);
  }

  container
    .addSeparatorComponents(
      new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
    )
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(`**Administrator:** ${actorField(auditEntry)}`)
    );

  for (const field of fields) {
    container.addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `**${truncate(field.name, 200)}:** ${truncate(field.value, 1000)}`
      )
    );
  }

  try {
    await channel.send({
      components: [container],
      flags: MessageFlags.IsComponentsV2,
      allowedMentions: { parse: [] }
    });
  } catch (error) {
    console.error(`Nie udało się wysłać logu na kanał ${LOG_CHANNEL_ID}:`, error);
  }
}

function memberField(member) {
  return `<@${member.id}>`;
}

function roleNames(roles) {
  return roles.map(role => `<@&${role.id}>`).join(', ') || 'Brak';
}

function permissionNames(role) {
  return role.permissions.toArray().map(permission =>
    permission.replace(/([a-z])([A-Z])/g, '$1 $2')
  );
}

async function handleMemberUpdate(oldMember, newMember) {
  const addedRoles = newMember.roles.cache.filter(role => !oldMember.roles.cache.has(role.id));
  const removedRoles = oldMember.roles.cache.filter(role => !newMember.roles.cache.has(role.id));
  const nicknameChanged = oldMember.nickname !== newMember.nickname;
  const oldTimeout = oldMember.communicationDisabledUntilTimestamp;
  const newTimeout = newMember.communicationDisabledUntilTimestamp;
  const timeoutChanged = oldTimeout !== newTimeout;

  if (!addedRoles.size && !removedRoles.size && !nicknameChanged && !timeoutChanged) return;

  if (nicknameChanged) {
    const auditEntry = await findAuditEntry(
      newMember.guild,
      AuditLogEvent.MemberUpdate,
      newMember.id,
      undefined,
      'nick'
    );
    await sendLog(newMember.guild, {
      title: 'Zmieniono pseudonim użytkownika',
      fields: [
        { name: 'Użytkownik', value: memberField(newMember) },
        { name: 'Poprzedni pseudonim', value: oldMember.nickname || 'Brak' },
        { name: 'Nowy pseudonim', value: newMember.nickname || 'Brak' }
      ],
      auditEntry
    });
  }

  if (timeoutChanged) {
    const auditEntry = await findAuditEntry(
      newMember.guild,
      AuditLogEvent.MemberUpdate,
      newMember.id,
      undefined,
      'communication_disabled_until'
    );
    const active = newTimeout && newTimeout > Date.now();
    await sendLog(newMember.guild, {
      title: active ? 'Nałożono przerwę (timeout)' : 'Usunięto przerwę (timeout)',
      color: active ? 0xFEE75C : 0x57F287,
      fields: [
        { name: 'Użytkownik', value: memberField(newMember) },
        {
          name: active ? 'Przerwa do' : 'Status',
          value: active ? `<t:${Math.floor(newTimeout / 1000)}:F> (<t:${Math.floor(newTimeout / 1000)}:R>)` : 'Przerwa została zdjęta.'
        }
      ],
      auditEntry
    });
  }

  if (addedRoles.size || removedRoles.size) {
    const roleAuditEntry = await findAuditEntry(
      newMember.guild,
      AuditLogEvent.MemberRoleUpdate,
      newMember.id
    );
    await sendLog(newMember.guild, {
      title: 'Zmieniono role użytkownika',
      fields: [
        { name: 'Użytkownik', value: memberField(newMember) },
        { name: 'Dodane role', value: roleNames([...addedRoles.values()]) },
        { name: 'Usunięte role', value: roleNames([...removedRoles.values()]) }
      ],
      auditEntry: roleAuditEntry
    });
  }
}

function registerAuditLogs(client) {
  client.on('guildMemberUpdate', (oldMember, newMember) => {
    handleMemberUpdate(oldMember, newMember).catch(error =>
      console.error('Błąd logowania zmian użytkownika:', error)
    );
  });

  client.on('guildBanAdd', async ban => {
    const auditEntry = await findAuditEntry(ban.guild, AuditLogEvent.MemberBanAdd, ban.user.id);
    await sendLog(ban.guild, {
      title: 'Zbanowano użytkownika',
      fields: [
        { name: 'Użytkownik', value: `<@${ban.user.id}>` },
        { name: 'Powód', value: auditEntry?.reason || 'Nie podano powodu.' }
      ],
      auditEntry
    });
  });

  client.on('guildBanRemove', async ban => {
    const auditEntry = await findAuditEntry(ban.guild, AuditLogEvent.MemberBanRemove, ban.user.id);
    await sendLog(ban.guild, {
      title: 'Odbanowano użytkownika',
      fields: [{ name: 'Użytkownik', value: `<@${ban.user.id}>` }],
      auditEntry
    });
  });

  client.on('guildMemberRemove', async member => {
    const auditEntry = await findAuditEntry(member.guild, AuditLogEvent.MemberKick, member.id);
    if (!auditEntry) return;

    await sendLog(member.guild, {
      title: 'Wyrzucono użytkownika',
      color: 0xED4245,
      fields: [
        { name: 'Użytkownik', value: memberField(member) },
        { name: 'Powód', value: auditEntry.reason || 'Nie podano powodu.' }
      ],
      auditEntry
    });
  });

  client.on('roleCreate', async role => {
    const auditEntry = await findAuditEntry(role.guild, AuditLogEvent.RoleCreate, role.id);
    await sendLog(role.guild, {
      title: 'Utworzono rolę',
      fields: [
        { name: 'Rola', value: `<@&${role.id}>` },
        { name: 'Nazwa', value: role.name },
        { name: 'Uprawnienia', value: permissionNames(role).join(', ') || 'Brak' }
      ],
      auditEntry
    });
  });

  client.on('roleDelete', async role => {
    const auditEntry = await findAuditEntry(role.guild, AuditLogEvent.RoleDelete, role.id);
    await sendLog(role.guild, {
      title: 'Usunięto rolę',
      fields: [
        { name: 'Rola', value: `\`${role.name}\`` }
      ],
      auditEntry
    });
  });

  client.on('roleUpdate', async (oldRole, newRole) => {
    const before = new Set(permissionNames(oldRole));
    const after = new Set(permissionNames(newRole));
    const added = [...after].filter(permission => !before.has(permission));
    const removed = [...before].filter(permission => !after.has(permission));
    if (!added.length && !removed.length) return;

    const auditEntry = await findAuditEntry(newRole.guild, AuditLogEvent.RoleUpdate, newRole.id);
    await sendLog(newRole.guild, {
      title: 'Zmieniono uprawnienia roli',
      fields: [
        { name: 'Rola', value: `<@&${newRole.id}>` },
        { name: 'Dodane uprawnienia', value: added.join(', ') || 'Brak' },
        { name: 'Usunięte uprawnienia', value: removed.join(', ') || 'Brak' }
      ],
      auditEntry
    });
  });

  client.on('messageDelete', async message => {
    if (!message.guild || message.channel.id === LOG_CHANNEL_ID) return;

    const auditEntry = await findAuditEntry(
      message.guild,
      AuditLogEvent.MessageDelete,
      message.author?.id,
      message.channel.id
    );
    const attachments = [...message.attachments.values()].map(attachment => attachment.url);
    await sendLog(message.guild, {
      title: 'Usunięto wiadomość',
      color: 0xED4245,
      fields: [
        {
          name: 'Autor wiadomości',
          value: message.author ? `<@${message.author.id}>` : 'Nieznany (wiadomość nie była w cache)'
        },
        { name: 'Kanał', value: `<#${message.channel.id}>` },
        { name: 'Treść', value: message.content || 'Brak treści tekstowej lub wiadomość nie była w cache.' },
        ...(attachments.length ? [{ name: 'Załączniki', value: attachments.join('\n') }] : []),
        { name: 'ID wiadomości', value: message.id }
      ],
      auditEntry
    });
  });

  client.on('messageDeleteBulk', async (messages, channel) => {
    if (!channel.guild || channel.id === LOG_CHANNEL_ID) return;

    const auditEntry = await findAuditEntry(
      channel.guild,
      AuditLogEvent.MessageBulkDelete,
      undefined,
      channel.id
    );
    await sendLog(channel.guild, {
      title: 'Usunięto wiele wiadomości',
      fields: [
        { name: 'Kanał', value: `<#${channel.id}>` },
        { name: 'Liczba wiadomości', value: String(messages.size) }
      ],
      auditEntry
    });
  });

  client.on('threadCreate', async thread => {
    const auditEntry = await findAuditEntry(thread.guild, AuditLogEvent.ThreadCreate, thread.id);
    await sendLog(thread.guild, {
      title: 'Utworzono wątek',
      fields: [
        { name: 'Wątek', value: `<#${thread.id}>` },
        { name: 'Kanał nadrzędny', value: thread.parentId ? `<#${thread.parentId}>` : 'Brak' }
      ],
      auditEntry
    });
  });

  client.on('threadDelete', async thread => {
    const auditEntry = await findAuditEntry(thread.guild, AuditLogEvent.ThreadDelete, thread.id);
    await sendLog(thread.guild, {
      title: 'Usunięto wątek',
      fields: [
        { name: 'Nazwa wątku', value: thread.name },
        { name: 'ID wątku', value: thread.id },
        { name: 'Kanał nadrzędny', value: thread.parentId ? `<#${thread.parentId}>` : 'Brak' }
      ],
      auditEntry
    });
  });
}

module.exports = registerAuditLogs;
