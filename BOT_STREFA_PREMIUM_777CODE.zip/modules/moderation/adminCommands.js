const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  ContainerBuilder,
  EmbedBuilder,
  MessageFlags,
  SeparatorBuilder,
  SeparatorSpacingSize,
  PermissionsBitField,
  TextDisplayBuilder
} = require('discord.js');
const { randomUUID } = require('crypto');
const fs = require('fs');
const path = require('path');

const CLIENT_ROLE_ID = '1556246277753282661';
const REP_CHANNEL_ID = process.env.LEGITCHECK_SOURCE_CHANNEL_ID;
const DM_CONFIRMATION_TTL = 60_000;
const PRODUCTS_PATH = path.join(__dirname, '..', '..', 'data', 'rep_products.json');
const ADMIN_COMMANDS = new Set([
  'wygeneruj_rep',
  'dodaj_produkt',
  'usun_produkt',
  'lista_produktow',
  'klient',
  'clear',
  'massrole',
  'embed',
  'dmall'
]);
const pendingDmConfirmations = new Map();

let products = [];
try {
  if (fs.existsSync(PRODUCTS_PATH)) {
    const storedProducts = JSON.parse(fs.readFileSync(PRODUCTS_PATH, 'utf8'));
    if (!Array.isArray(storedProducts) || storedProducts.some(product => typeof product !== 'string')) {
      throw new Error('rep_products.json must contain an array of product names.');
    }
    products = storedProducts;
  }
} catch (error) {
  console.error('Nie udało się wczytać listy produktów:', error);
  throw error;
}

let productWriteQueue = Promise.resolve();

function response(content) {
  return {
    components: [new ContainerBuilder().addTextDisplayComponents(
      new TextDisplayBuilder().setContent(content)
    )],
    flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
    allowedMentions: { parse: [] }
  };
}

function v2Message(content) {
  return {
    components: [new ContainerBuilder().addTextDisplayComponents(
      new TextDisplayBuilder().setContent(content)
    )],
    flags: MessageFlags.IsComponentsV2,
    allowedMentions: { parse: [] }
  };
}

function isAdministrator(interaction) {
  return interaction.member?.permissions.has(PermissionsBitField.Flags.Administrator);
}

function requireAdministrator(interaction) {
  if (isAdministrator(interaction)) return null;
  return interaction.editReply(response('❌ Ta komenda jest dostępna tylko dla administratorów.'));
}

function findProduct(input) {
  const normalized = input.trim().toLocaleLowerCase('pl');
  return products.find(product => product.toLocaleLowerCase('pl') === normalized) || null;
}

function saveProducts() {
  const snapshot = JSON.stringify(products, null, 2);
  productWriteQueue = productWriteQueue.catch(() => {}).then(async () => {
    await fs.promises.mkdir(path.dirname(PRODUCTS_PATH), { recursive: true });
    const temporaryPath = `${PRODUCTS_PATH}.tmp`;
    await fs.promises.writeFile(temporaryPath, snapshot, 'utf8');
    await fs.promises.rename(temporaryPath, PRODUCTS_PATH);
  });
  return productWriteQueue;
}

async function runWithConcurrency(items, concurrency, callback) {
  let nextIndex = 0;
  const workers = Array.from(
    { length: Math.min(concurrency, items.length) },
    async () => {
      while (nextIndex < items.length) {
        const index = nextIndex;
        nextIndex += 1;
        await callback(items[index]);
      }
    }
  );
  await Promise.all(workers);
}

module.exports = {
  name: 'adminCommandListener',

  async onAutocompleteInteraction(interaction) {
    if (interaction.commandName !== 'wygeneruj_rep') return;
    const focused = interaction.options.getFocused().toLocaleLowerCase('pl');
    const choices = products
      .filter(product => product.toLocaleLowerCase('pl').includes(focused))
      .slice(0, 25)
      .map(product => ({ name: product.slice(0, 100), value: product.slice(0, 100) }));
    try {
      await interaction.respond(choices);
    } catch (error) {
      if (error.code === 10062 || error.code === 40060) {
        console.warn(`Pominięto nieaktualną odpowiedź autouzupełniania dla /${interaction.commandName} (${error.code}).`);
        return;
      }
      throw error;
    }
  },

  async onSlashCommandInteraction(interaction) {
    const { commandName } = interaction;
    if (!ADMIN_COMMANDS.has(commandName)) return;
    if (interaction.deferred || interaction.replied) return;

    await interaction.deferReply({
      flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2
    });

    if (commandName === 'wygeneruj_rep') {
      const denied = requireAdministrator(interaction);
      if (denied) return denied;
      const product = findProduct(interaction.options.getString('produkt', true));
      if (!product) return interaction.editReply(response('❌ Nie znaleziono produktu. Wybierz go z listy podpowiedzi.'));
      const seller = interaction.options.getUser('sprzedawca', true);
      const buyer = interaction.options.getUser('kupujacy', true);
      const repMessage = `+rep @${seller.username} ${product}`;

      if (
        interaction.channel?.type === ChannelType.GuildText &&
        interaction.channel.topic?.includes('creator=')
      ) {
        try {
          await interaction.channel.setTopic(
            interaction.channel.topic
              .split(';')
              .filter(part => !part.startsWith('repBuyer='))
              .concat(`repBuyer=${buyer.id}`)
              .join(';')
          );
        } catch (error) {
          console.error(`Nie udało się powiązać kupującego ${buyer.id} z ticketem ${interaction.channel.id}:`, error);
          return interaction.editReply(response(
            '❌ Nie udało się powiązać kupującego z ticketem. Bot musi mieć uprawnienie „Zarządzanie kanałami”, aby ticket mógł zostać automatycznie zamknięty.'
          ));
        }
      }

      try {
        await buyer.send({
          components: [
            new ContainerBuilder()
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent('## ✅ TWOJ SERWER × WYSTAW NAM LEGIT CHECKA')
              )
              .addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
              )
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                  `Dziękujemy za skorzystanie z naszych usług!\n` +
                  `Prosimy o wystawienie legit checka na kanale <#${REP_CHANNEL_ID}>.`
                )
              )
              .addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
              )
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`📝 **Wzór:**\n\`\`\`${repMessage}\`\`\``)
              )
              .addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
              )
              .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                  `⚠️ Po wystawieniu legit checka ticket zostanie automatycznie zamknięty, ` +
                  `ponieważ zamówienie uznajemy wtedy za zrealizowane.\n\n` +
                  `[Przejdź do kanału legit checków](https://discord.com/channels/${interaction.guildId}/${REP_CHANNEL_ID})`
                )
              )
          ],
          flags: MessageFlags.IsComponentsV2,
          allowedMentions: { parse: [] }
        });
      } catch (error) {
        console.error(`Nie udało się wysłać prośby o +rep do kupującego ${buyer.id}:`, error);
        return interaction.editReply(response('❌ Nie udało się wysłać wiadomości DM. Użytkownik może mieć zablokowane wiadomości prywatne.'));
      }

      return interaction.editReply(response(
        `✅ Wygenerowano prośbę o +rep dla <@${buyer.id}> z oznaczeniem sprzedawcy <@${seller.id}>.\n\n` +
        `Wiadomość do skopiowania: \`${repMessage}\`\n` +
        `Kupujący otrzymał DM z instrukcją wklejenia jej na <#${REP_CHANNEL_ID}>.`
      ));
    }

    if (commandName === 'embed') {
      const denied = requireAdministrator(interaction);
      if (denied) return denied;
      const channel = interaction.channel;
      if (!channel?.isTextBased() || typeof channel.send !== 'function') {
        return interaction.editReply(response('❌ Tej komendy można użyć tylko na kanale tekstowym.'));
      }

      const title = interaction.options.getString('tytul', true);
      const description = interaction.options.getString('tresc', true);
      const colorInput = interaction.options.getString('kolor');
      if (colorInput && !/^#[0-9a-f]{6}$/i.test(colorInput)) {
        return interaction.editReply(response('❌ Kolor musi mieć format #RRGGBB, np. #5865F2.'));
      }

      const embed = new EmbedBuilder()
        .setTitle(title)
        .setDescription(description)
        .setColor(colorInput ? Number.parseInt(colorInput.slice(1), 16) : 0x5865F2);
      try {
        await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
      } catch (error) {
        console.error('Nie udało się wysłać embeda:', error);
        return interaction.editReply(response('❌ Nie udało się wysłać embeda. Sprawdź uprawnienie „Wysyłanie wiadomości”.'));
      }
      return interaction.editReply(response('✅ Wysłano embed na tym kanale.'));
    }

    if (commandName === 'dmall') {
      const denied = requireAdministrator(interaction);
      if (denied) return denied;
      if (!interaction.guild) {
        return interaction.editReply(response('❌ Tej komendy można użyć tylko na serwerze.'));
      }

      const confirmationId = randomUUID();
      const content = interaction.options.getString('tresc', true);
      const timer = setTimeout(() => pendingDmConfirmations.delete(confirmationId), DM_CONFIRMATION_TTL);
      if (typeof timer.unref === 'function') timer.unref();
      pendingDmConfirmations.set(confirmationId, {
        guildId: interaction.guildId,
        userId: interaction.user.id,
        content
      });

      return interaction.editReply({
        components: [
          new ContainerBuilder()
            .addTextDisplayComponents(
              new TextDisplayBuilder().setContent(
                `## Potwierdź wysyłkę DM\n` +
                `Wiadomość zostanie wysłana w formacie Components V2 do wszystkich członków **${interaction.guild.name}** (bez botów).\n\n` +
                `Podgląd: ${content.slice(0, 1200)}${content.length > 1200 ? '…' : ''}`
              )
            )
            .addActionRowComponents(
              new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                  .setCustomId(`dmall:confirm:${confirmationId}`)
                  .setLabel('Wyślij do wszystkich')
                  .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                  .setCustomId(`dmall:cancel:${confirmationId}`)
                  .setLabel('Anuluj')
                  .setStyle(ButtonStyle.Secondary)
              )
            )
        ],
        flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral,
        allowedMentions: { parse: [] }
      });
    }

    if (commandName === 'dodaj_produkt') {
      const denied = requireAdministrator(interaction);
      if (denied) return denied;
      const product = interaction.options.getString('nazwa', true).trim();
      if (!product || product.length > 100) {
        return interaction.editReply(response('❌ Nazwa produktu musi mieć od 1 do 100 znaków.'));
      }
      if (findProduct(product)) return interaction.editReply(response('ℹ️ Ten produkt jest już na liście.'));
      products.push(product);
      await saveProducts();
      return interaction.editReply(response(`✅ Dodano produkt **${product}**.`));
    }

    if (commandName === 'usun_produkt') {
      const denied = requireAdministrator(interaction);
      if (denied) return denied;
      const product = findProduct(interaction.options.getString('nazwa', true));
      if (!product) return interaction.editReply(response('❌ Nie znaleziono takiego produktu.'));
      products = products.filter(existing => existing !== product);
      await saveProducts();
      return interaction.editReply(response(`✅ Usunięto produkt **${product}**.`));
    }

    if (commandName === 'lista_produktow') {
      const denied = requireAdministrator(interaction);
      if (denied) return denied;
      const list = products.length
        ? products.map((product, index) => `${index + 1}. ${product}`).join('\n')
        : 'Lista produktów jest pusta.';
      return interaction.editReply(response(`## Produkty do +rep\n${list}`));
    }

    if (commandName === 'klient') {
      const denied = requireAdministrator(interaction);
      if (denied) return denied;
      const member = interaction.options.getMember('uzytkownik');
      if (!member) return interaction.editReply(response('❌ Użytkownik musi należeć do tego serwera.'));
      const role = interaction.guild.roles.cache.get(CLIENT_ROLE_ID);
      if (!role) return interaction.editReply(response(`❌ Nie znaleziono roli klienta \`${CLIENT_ROLE_ID}\`.`));
      if (member.roles.cache.has(role.id)) {
        return interaction.editReply(response(`ℹ️ <@${member.id}> ma już rolę <@&${role.id}>.`));
      }
      await member.roles.add(role, `Rola klienta nadana przez ${interaction.user.tag}`);
      return interaction.editReply(response(`✅ Nadano użytkownikowi <@${member.id}> rolę <@&${role.id}>.`));
    }

    if (commandName === 'clear') {
      const denied = requireAdministrator(interaction);
      if (denied) return denied;
      const channel = interaction.channel;
      if (channel.type !== ChannelType.GuildText) {
        return interaction.editReply(response('❌ Komendy można użyć tylko na kanale tekstowym.'));
      }
      const amount = interaction.options.getInteger('ilosc', true);
      const deleted = await channel.bulkDelete(amount, true);
      return interaction.editReply(response(`✅ Usunięto **${deleted.size}** z ${amount} wskazanych wiadomości. Wiadomości starsze niż 14 dni są pomijane przez Discorda.`));
    }

    if (commandName === 'massrole') {
      const denied = requireAdministrator(interaction);
      if (denied) return denied;
      const role = interaction.options.getRole('rola', true);
      if (role.id === interaction.guildId || role.managed) {
        return interaction.editReply(response('❌ Nie można masowo nadać roli @everyone ani roli zarządzanej przez integrację.'));
      }
      const botMember = interaction.guild.members.me;
      if (!botMember?.permissions.has(PermissionsBitField.Flags.ManageRoles) || !role.editable) {
        return interaction.editReply(response('❌ Bot nie może zarządzać tą rolą. Sprawdź uprawnienie Manage Roles i hierarchię ról.'));
      }

      try {
        const members = await interaction.guild.members.fetch();
        const targets = [...members.values()].filter(member =>
          !member.user.bot && !member.roles.cache.has(role.id)
        );
        let succeeded = 0;
        let failed = 0;
        await runWithConcurrency(targets, 5, async member => {
          try {
            await member.roles.add(role, `Masowe nadanie roli przez ${interaction.user.tag}`);
            succeeded += 1;
          } catch (error) {
            failed += 1;
            console.error(`Nie udało się nadać roli ${role.id} użytkownikowi ${member.id}:`, error);
          }
        });
        return interaction.editReply(response(
          `## Masowe nadawanie roli zakończone\n` +
          `Rola: <@&${role.id}>\n` +
          `Nadano: **${succeeded}** z **${targets.length}** osób.\n` +
          (failed ? `Niepowodzenia: **${failed}**.` : 'Bez błędów.')
        ));
      } catch (error) {
        console.error('Masowe pobieranie członków lub nadawanie roli nie powiodło się:', error);
        return interaction.editReply(response('❌ Nie udało się pobrać członków serwera ani wykonać masowego nadawania roli.'));
      }
    }
  },

  async onButtonInteraction(interaction) {
    if (!interaction.customId.startsWith('dmall:')) return;

    const [, action, confirmationId] = interaction.customId.split(':');
    const confirmation = pendingDmConfirmations.get(confirmationId);
    if (!confirmation || confirmation.guildId !== interaction.guildId) {
      return interaction.reply(response('❌ Potwierdzenie wygasło. Uruchom ponownie `/dmall`.'));
    }
    if (confirmation.userId !== interaction.user.id) {
      return interaction.reply(response('❌ Tylko administrator, który rozpoczął wysyłkę, może ją potwierdzić.'));
    }
    if (!interaction.member?.permissions.has(PermissionsBitField.Flags.Administrator)) {
      pendingDmConfirmations.delete(confirmationId);
      return interaction.reply(response('❌ Wysyłkę może potwierdzić tylko administrator.'));
    }

    pendingDmConfirmations.delete(confirmationId);
    if (action === 'cancel') {
      await interaction.update(v2Message('Wysyłka DM została anulowana.'));
      return;
    }
    if (action !== 'confirm') return;

    await interaction.update(v2Message('⏳ Pobieram członków serwera i rozpoczynam wysyłkę wiadomości prywatnych...'));
    try {
      const members = await interaction.guild.members.fetch();
      const targets = [...members.values()].filter(member => !member.user.bot);
      let sent = 0;
      let failed = 0;

      await runWithConcurrency(targets, 3, async member => {
        try {
          await member.send(v2Message(confirmation.content));
          sent += 1;
        } catch (error) {
          failed += 1;
          if (error.code !== 50007) {
            console.error(`Nie udało się wysłać DM do użytkownika ${member.id}:`, error);
          }
        }
      });

      await interaction.editReply(v2Message(
        `## Wysyłka DM zakończona\nWysłano: **${sent}** z **${targets.length}** wiadomości.` +
        (failed ? `\nNie udało się wysłać: **${failed}**.` : '')
      ));
    } catch (error) {
      console.error('Masowa wysyłka DM nie powiodła się:', error);
      await interaction.editReply(v2Message('❌ Nie udało się pobrać członków serwera ani zakończyć wysyłki DM.'));
    }
  }
};
