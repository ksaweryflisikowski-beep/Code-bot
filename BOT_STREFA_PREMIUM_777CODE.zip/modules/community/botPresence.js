const { ActivityType } = require('discord.js');

const TARGET_GUILD_ID = process.env.WELCOME_DM_GUILD_ID;
const ROTATE_INTERVAL_MS = 15000;
const STREAM_URL = 'https://www.twitch.tv/twojserwer';

function getMemberCount(client) {
  const guild = TARGET_GUILD_ID ? client.guilds.cache.get(TARGET_GUILD_ID) : null;
  if (guild) return guild.memberCount;
  return client.guilds.cache.reduce((total, g) => total + g.memberCount, 0);
}

module.exports = {
  name: 'botPresence',

  onClientReady(client) {
    let index = 0;

    const applyPresence = () => {
      const statuses = [
        `${getMemberCount(client)} osób na serwerze`,
        'discord.gg/twojserwer'
      ];

      client.user.setPresence({
        status: 'online',
        activities: [
          {
            name: statuses[index % statuses.length],
            type: ActivityType.Streaming,
            url: STREAM_URL
          }
        ]
      });

      index++;
    };

    applyPresence();
    setInterval(applyPresence, ROTATE_INTERVAL_MS);
  }
};
