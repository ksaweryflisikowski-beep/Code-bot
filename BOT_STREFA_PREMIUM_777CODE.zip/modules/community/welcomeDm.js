const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  AttachmentBuilder,
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SectionBuilder,
  ThumbnailBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder
} = require('discord.js');
const path = require('path');
const fs = require('fs');

const TARGET_GUILD_ID = process.env.WELCOME_DM_GUILD_ID;
const REGULAMIN_CHANNEL_ID = process.env.REGULAMIN_CHANNEL_ID;
const VERIFICATION_CHANNEL_ID = process.env.VERIFICATION_CHANNEL_ID;
const BANNER_URL = process.env.BANNER_URL;
const THUMBNAIL_URL = process.env.THUMBNAIL_URL;

module.exports = {
  name: 'welcomeDmListener',

  async onGuildMemberAdd(member) {
    if (!TARGET_GUILD_ID) {
      console.warn('[welcomeDm] Brak WELCOME_DM_GUILD_ID w pliku .env — pomijam powitanie DM.');
      return;
    }

    if (member.guild.id !== TARGET_GUILD_ID) return;

    const guildName = member.guild.name;
    const files = [];
    let bannerUrl = BANNER_URL;

    if (!bannerUrl) {
      const bannerPath = path.join(__dirname, '..', '..', 'banner.png');
      if (fs.existsSync(bannerPath)) {
        files.push(new AttachmentBuilder(bannerPath, { name: 'banner.png' }));
        bannerUrl = 'attachment://banner.png';
      }
    }

    const regulaminPart = REGULAMIN_CHANNEL_ID ? ` który znajdziesz na kanale <#${REGULAMIN_CHANNEL_ID}>` : '';
    const verificationPart = VERIFICATION_CHANNEL_ID ? `<#${VERIFICATION_CHANNEL_ID}>` : 'kanale weryfikacji';

    const container = new ContainerBuilder()
      .addTextDisplayComponents(new TextDisplayBuilder().setContent(`## WITAJ NA ${guildName}!`))
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
      .addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
              `> Witaj <@${member.id}> !\n\n` +
              `> Właśnie dołączyłeś na **__oficjalny serwer__** discord **${guildName}**`
            )
          )
          .setThumbnailAccessory(new ThumbnailBuilder().setURL(THUMBNAIL_URL || member.user.displayAvatarURL()))
      )
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `> Zapoznaj się z regulaminem${regulaminPart} a następnie zweryfikuj się na ${verificationPart}!`
        )
      );

    if (bannerUrl) {
      container.addMediaGalleryComponents(
        new MediaGalleryBuilder().addItems(
          new MediaGalleryItemBuilder().setURL(bannerUrl)
        )
      );
    }

    const footerRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('wdm_title')
        .setLabel(`        Witaj na ${guildName}!        `)
        .setStyle(ButtonStyle.Secondary)
        .setDisabled(true)
    );

    container
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
      .addActionRowComponents(footerRow);

    try {
      await member.send({
        components: [container],
        files,
        flags: MessageFlags.IsComponentsV2
      });
    } catch (error) {
      console.error(`[welcomeDm] Nie udało się wysłać powitania DM do ${member.user.id}:`, error);
    }
  }
};
