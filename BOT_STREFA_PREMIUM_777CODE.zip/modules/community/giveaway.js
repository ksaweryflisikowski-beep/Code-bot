const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ContainerBuilder,
  MessageFlags,
  PermissionsBitField,
  SeparatorBuilder,
  SeparatorSpacingSize,
  SectionBuilder,
  TextDisplayBuilder,
  ThumbnailBuilder
} = require('discord.js');
const fs = require('fs');
const path = require('path');

const GIVEAWAYS_PATH = path.join(__dirname, '..', '..', 'data', 'giveaways.json');
const MAX_DURATION_MS = 30 * 24 * 60 * 60 * 1000;
const MAX_WINNERS = 20;
const BUTTON_PREFIX = 'giveaway:join:';
const THUMBNAIL_URL = process.env.THUMBNAIL_URL;

let giveaways = {};
try {
  if (fs.existsSync(GIVEAWAYS_PATH)) {
    giveaways = JSON.parse(fs.readFileSync(GIVEAWAYS_PATH, 'utf8'));
  }
} catch (error) {
  console.error('Nie udało się wczytać konkursów:', error);
  throw error;
}

let writeQueue = Promise.resolve();
const timers = new Map();

function saveGiveaways() {
  const snapshot = JSON.stringify(giveaways, null, 2);
  writeQueue = writeQueue.catch(() => {}).then(async () => {
    await fs.promises.mkdir(path.dirname(GIVEAWAYS_PATH), { recursive: true });
    const temporaryPath = `${GIVEAWAYS_PATH}.tmp`;
    await fs.promises.writeFile(temporaryPath, snapshot, 'utf8');
    await fs.promises.rename(temporaryPath, GIVEAWAYS_PATH);
  });
  return writeQueue;
}

function v2Flags(ephemeral = false) {
  return ephemeral
    ? (MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral)
    : MessageFlags.IsComponentsV2;
}

const text = (content) => new TextDisplayBuilder().setContent(content);
const sep = () => new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);

function quoteBlock(value) {
  return String(value)
    .split('\n')
    .map(line => `> ${line}`)
    .join('\n');
}

function ephemeral(content) {
  const container = new ContainerBuilder()
    .addTextDisplayComponents(text(content));
  return {
    components: [container],
    flags: v2Flags(true),
    allowedMentions: { parse: [] }
  };
}

const successReply = (content) => ephemeral(content);

function parseDuration(value) {
  const match = /^(\d+)\s*(s|m|h|d)$/i.exec(value.trim());
  if (!match) return null;

  const amount = Number(match[1]);
  const unitMs = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000 }[match[2].toLowerCase()];
  const duration = amount * unitMs;
  if (!Number.isSafeInteger(duration) || duration < 10_000 || duration > MAX_DURATION_MS) return null;
  return duration;
}

function joinButtonRow(giveaway, disabled = false) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`${BUTTON_PREFIX}${giveaway.messageId}`)
      .setLabel(disabled ? 'KONKURS ZAKOŃCZONY' : `Weź udział (${giveaway.entries.length})`)
      .setStyle(disabled ? ButtonStyle.Secondary : ButtonStyle.Primary)
      .setDisabled(disabled)
  );
}

function headerSection(content) {
  if (THUMBNAIL_URL) {
    return new SectionBuilder()
      .addTextDisplayComponents(text(content))
      .setThumbnailAccessory(new ThumbnailBuilder().setURL(THUMBNAIL_URL));
  }
  return null;
}

function giveawayContainer(giveaway, ended = false, winners = []) {
  const endsSeconds = Math.floor(giveaway.endsAt / 1000);
  const startSeconds = Math.floor(giveaway.startedAt / 1000);
  const endedSeconds = Math.floor((giveaway.endedAt || giveaway.endsAt) / 1000);
  const header = ended
    ? `## KONKURS ZAKOŃCZONY\n### Nagroda: ${giveaway.prize}`
    : `## KONKURS\n### Nagroda: ${giveaway.prize}`;

  const container = new ContainerBuilder();

  const section = headerSection(header);
  if (section) {
    container.addSectionComponents(section);
  } else {
    container.addTextDisplayComponents(text(header));
  }

  if (giveaway.description) {
    container
      .addSeparatorComponents(sep())
      .addTextDisplayComponents(text(quoteBlock(giveaway.description)));
  }

  container.addSeparatorComponents(sep());

  if (ended) {
    const winnersList = winners.length
      ? winners.map(id => `> <@${id}>`).join('\n')
      : '> Nikt nie wziął udziału, więc nie wylosowano zwycięzcy.';
    container.addTextDisplayComponents(text(
      `### Zwycięzcy\n${winnersList}\n\n` +
      `-# Liczba uczestników: ${giveaway.entries.length} · Zakończono: <t:${endedSeconds}:F>`
    ));
  } else {
    container.addTextDisplayComponents(text(
      '### Szczegóły\n' +
      `**Liczba zwycięzców:** ${giveaway.winnerCount}\n` +
      `**Koniec:** <t:${endsSeconds}:F> (<t:${endsSeconds}:R>)\n` +
      `**Uczestnicy:** ${giveaway.entries.length}\n` +
      `**Rozpoczęto:** <t:${startSeconds}:F>`
    ));
  }

  if (giveaway.messageId) {
    container
      .addSeparatorComponents(sep())
      .addActionRowComponents(joinButtonRow(giveaway, ended))
      .addTextDisplayComponents(text(`-# ID konkursu: \`${giveaway.messageId}\``));
  }

  return container;
}

function announcementPayload(giveaway, winners) {
  const hasWinners = winners.length > 0;
  const body = hasWinners
    ? `## Gratulacje!\n${winners.map(id => `> <@${id}>`).join('\n')}\n> Wygrywasz **${giveaway.prize}** — odbierz nagrodę u administracji.`
    : `## KONKURS ZAKOŃCZONY\n> Konkurs o **${giveaway.prize}** zakończył się bez uczestników.`;

  const container = new ContainerBuilder()
    .addTextDisplayComponents(text(body));

  return {
    components: [container],
    flags: v2Flags(),
    allowedMentions: { users: winners }
  };
}

function sampleWinners(entries, count) {
  const remaining = [...entries];
  const winners = [];
  while (remaining.length && winners.length < count) {
    const index = Math.floor(Math.random() * remaining.length);
    winners.push(remaining.splice(index, 1)[0]);
  }
  return winners;
}

async function finishGiveaway(client, giveaway) {
  if (giveaway.endedAt) return;
  giveaway.endedAt = Date.now();
  giveaway.winnerIds = sampleWinners(giveaway.entries, giveaway.winnerCount);
  await saveGiveaways();

  const channel = await client.channels.fetch(giveaway.channelId).catch(error => {
    console.error(`Nie udało się pobrać kanału konkursu ${giveaway.messageId}:`, error);
    return null;
  });
  if (!channel?.isTextBased() || typeof channel.messages?.fetch !== 'function') {
    console.error(`Kanał konkursu ${giveaway.messageId} nie jest dostępny.`);
    return;
  }

  const message = await channel.messages.fetch(giveaway.messageId).catch(error => {
    console.error(`Nie udało się pobrać wiadomości konkursu ${giveaway.messageId}:`, error);
    return null;
  });
  if (!message) return;

  await message.edit({
    components: [giveawayContainer(giveaway, true, giveaway.winnerIds)],
    allowedMentions: { parse: [] }
  });

  await channel.send(announcementPayload(giveaway, giveaway.winnerIds));
}

function scheduleGiveaway(client, giveaway) {
  if (giveaway.endedAt) return;
  const existingTimer = timers.get(giveaway.messageId);
  if (existingTimer) clearTimeout(existingTimer);

  const delay = Math.max(0, giveaway.endsAt - Date.now());
  const timer = setTimeout(() => {
    timers.delete(giveaway.messageId);
    finishGiveaway(client, giveaway).catch(error =>
      console.error(`Nie udało się zakończyć konkursu ${giveaway.messageId}:`, error)
    );
  }, delay);
  timers.set(giveaway.messageId, timer);
}

module.exports = {
  name: 'giveawayCommandListener',

  onClientReady(client) {
    for (const giveaway of Object.values(giveaways)) {
      if (!giveaway.endedAt) scheduleGiveaway(client, giveaway);
    }
  },

  async onSlashCommandInteraction(interaction) {
    if (!['konkurs', 'reroll'].includes(interaction.commandName)) return;
    if (!interaction.guild || !interaction.member?.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return interaction.reply(ephemeral('Tej komendy może użyć wyłącznie administrator serwera.'));
    }

    if (interaction.commandName === 'konkurs') {
      const prize = interaction.options.getString('nagroda', true).trim();
      const durationInput = interaction.options.getString('czas', true);
      const durationMs = parseDuration(durationInput);
      const winnerCount = interaction.options.getInteger('zwyciezcy', true);
      const channel = interaction.options.getChannel('kanal') || interaction.channel;
      const description = interaction.options.getString('opis')?.trim() || '';

      if (!prize || prize.length > 200) {
        return interaction.reply(ephemeral('Nagroda musi mieć od 1 do 200 znaków.'));
      }
      if (!durationMs) {
        return interaction.reply(ephemeral('Nieprawidłowy czas. Użyj formatu `30s`, `10m`, `2h` lub `7d` (minimum 10 sekund, maksimum 30 dni).'));
      }
      if (winnerCount < 1 || winnerCount > MAX_WINNERS) {
        return interaction.reply(ephemeral(`Liczba zwycięzców musi wynosić od 1 do ${MAX_WINNERS}.`));
      }
      if (!channel.isTextBased() || typeof channel.send !== 'function') {
        return interaction.reply(ephemeral('Wybrany kanał nie obsługuje wiadomości.'));
      }
      if (description.length > 1000) {
        return interaction.reply(ephemeral('Opis może mieć maksymalnie 1000 znaków.'));
      }

      const giveaway = {
        guildId: interaction.guild.id,
        channelId: channel.id,
        messageId: null,
        prize,
        description,
        winnerCount,
        startedAt: Date.now(),
        endsAt: Date.now() + durationMs,
        entries: [],
        winnerIds: [],
        endedAt: null
      };

      const message = await channel.send({
        components: [giveawayContainer(giveaway)],
        flags: v2Flags(),
        allowedMentions: { parse: [] }
      });
      giveaway.messageId = message.id;
      giveaways[message.id] = giveaway;

      try {
        await saveGiveaways();
        await message.edit({ components: [giveawayContainer(giveaway)] });
      } catch (error) {
        delete giveaways[message.id];
        await message.delete().catch(deleteError =>
          console.error(`Nie udało się usunąć niezapisanego konkursu ${message.id}:`, deleteError)
        );
        try {
          await saveGiveaways();
        } catch (cleanupError) {
          console.error(`Nie udało się usunąć konkursu ${message.id} z pamięci trwałej:`, cleanupError);
        }
        console.error('Nie udało się opublikować konkursu:', error);
        return interaction.reply(ephemeral('Wystąpił błąd podczas zapisywania konkursu.'));
      }

      scheduleGiveaway(interaction.client, giveaway);
      return interaction.reply(successReply(`Konkurs **${prize}** został opublikowany na <#${channel.id}>.`));
    }

    const messageId = interaction.options.getString('id_wiadomosci', true).trim();
    const giveaway = giveaways[messageId];
    if (!giveaway || giveaway.guildId !== interaction.guild.id) {
      return interaction.reply(ephemeral('Nie znaleziono konkursu o podanym ID wiadomości.'));
    }
    if (!giveaway.endedAt) {
      return interaction.reply(ephemeral('Nie można losować ponownie, dopóki konkurs trwa.'));
    }
    if (!giveaway.entries.length) {
      return interaction.reply(ephemeral('Nie można wylosować zwycięzcy — w konkursie nikt nie wziął udziału.'));
    }

    try {
      const channel = await interaction.client.channels.fetch(giveaway.channelId);
      if (!channel?.isTextBased() || typeof channel.send !== 'function') {
        return interaction.reply(ephemeral('Nie udało się odnaleźć kanału konkursu.'));
      }
      const message = await channel.messages.fetch(giveaway.messageId);
      const previousWinners = giveaway.winnerIds || [];
      const alternativeEntries = giveaway.entries.filter(id => !previousWinners.includes(id));
      const rerollPool = alternativeEntries.length ? alternativeEntries : giveaway.entries;
      const oldWinnerIds = giveaway.winnerIds;
      giveaway.winnerIds = sampleWinners(rerollPool, giveaway.winnerCount);
      try {
        await saveGiveaways();
      } catch (error) {
        giveaway.winnerIds = oldWinnerIds;
        throw error;
      }
      await message.edit({
        components: [giveawayContainer(giveaway, true, giveaway.winnerIds)],
        allowedMentions: { parse: [] }
      });
      await channel.send(announcementPayload(giveaway, giveaway.winnerIds));
      return interaction.reply(successReply(`Wylosowano ponownie zwycięzców konkursu **${giveaway.prize}**.`));
    } catch (error) {
      console.error(`Nie udało się ponownie wylosować konkursu ${messageId}:`, error);
      return interaction.reply(ephemeral('Nie udało się ponownie wylosować zwycięzców konkursu.'));
    }
  },

  async onButtonInteraction(interaction) {
    if (!interaction.customId.startsWith(BUTTON_PREFIX)) return;
    const messageId = interaction.customId.slice(BUTTON_PREFIX.length);
    const giveaway = giveaways[messageId];
    if (!giveaway || giveaway.endedAt || giveaway.endsAt <= Date.now()) {
      return interaction.reply(ephemeral('Ten konkurs jest już zakończony lub niedostępny.'));
    }
    if (interaction.guildId !== giveaway.guildId) {
      return interaction.reply(ephemeral('Nie można dołączyć do tego konkursu na tym serwerze.'));
    }

    const alreadyEntered = giveaway.entries.includes(interaction.user.id);
    giveaway.entries = alreadyEntered
      ? giveaway.entries.filter(id => id !== interaction.user.id)
      : [...giveaway.entries, interaction.user.id];
    await saveGiveaways();

    await interaction.update({
      components: [giveawayContainer(giveaway)],
      allowedMentions: { parse: [] }
    });
  }
};
