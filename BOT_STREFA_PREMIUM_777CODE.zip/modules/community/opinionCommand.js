const {
  StringSelectMenuBuilder,
  ModalBuilder,
  LabelBuilder,
  TextInputBuilder,
  TextInputStyle,
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  SectionBuilder,
  ThumbnailBuilder
} = require('discord.js');

const TARGET_CHANNEL_ID = process.env.OPINIA_TARGET_CHANNEL_ID;

const COLORS = {
  main: 0x5865F2,
  error: 0xED4245,
  warn: 0xFEE75C
};

const SELECT_PREFIX = 'opinia:ocena';
const CONTENT_MODAL_ID = 'opinia:tresc_modal';
const CONTENT_INPUT_ID = 'opinia:tresc_pole';

const RATING_CATEGORIES = [
  { key: 'czas', label: 'Czas oczekiwania' },
  { key: 'jakosc', label: 'Jakość produktu' },
  { key: 'cena', label: 'Cena produktu' }
];

const sessions = new Map();
const SESSION_TTL_MS = 30 * 60 * 1000;

function v2Flags(ephemeral = false) {
  return ephemeral
    ? (MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral)
    : MessageFlags.IsComponentsV2;
}

function text(content) {
  return new TextDisplayBuilder().setContent(content);
}

function separator() {
  return new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);
}

function statusPayload(content, { ephemeral = true } = {}) {
  return {
    components: [new ContainerBuilder().addTextDisplayComponents(text(content))],
    flags: v2Flags(ephemeral)
  };
}

function sessionKey(interaction) {
  return `${interaction.guildId}:${interaction.user.id}`;
}

function newSession() {
  return {
    createdAt: Date.now()
  };
}

function pruneSessions() {
  const now = Date.now();
  for (const [key, session] of sessions) {
    if (now - session.createdAt > SESSION_TTL_MS) sessions.delete(key);
  }
}

function starOptions() {
  return [1, 2, 3, 4, 5].map(n => ({
    label: '⭐'.repeat(n),
    value: String(n),
    description: `${n}/5`
  }));
}

function buildRatingMenu(category) {
  return new StringSelectMenuBuilder()
    .setCustomId(`${SELECT_PREFIX}:${category.key}`)
    .setPlaceholder(`⭐ ${category.label} — wybierz ocenę`)
    .setMinValues(1)
    .setMaxValues(1)
    .addOptions(starOptions());
}

function buildOpinionModal() {
  const contentInput = new TextInputBuilder()
    .setCustomId(CONTENT_INPUT_ID)
    .setPlaceholder('Napisz coś od siebie…')
    .setStyle(TextInputStyle.Paragraph)
    .setMinLength(3)
    .setMaxLength(1000)
    .setRequired(true);

  return new ModalBuilder()
    .setCustomId(CONTENT_MODAL_ID)
    .setTitle('Twoja opinia')
    .addLabelComponents(
      ...RATING_CATEGORIES.map(category =>
        new LabelBuilder()
          .setLabel(category.label)
          .setStringSelectMenuComponent(buildRatingMenu(category))
      ),
      new LabelBuilder()
        .setLabel('Treść opinii')
        .setTextInputComponent(contentInput)
    );
}

function buildOpinionContainer({ authorId, authorAvatarUrl, ratings, content }) {
  const ratingIcons = {
    czas: '`⏳`',
    jakosc: '`📋`',
    cena: '`💸`'
  };
  const ratingLines = RATING_CATEGORIES
    .map(category => {
      const rating = Number(ratings[category.key]);
      const ratingStars = Number.isInteger(rating) && rating >= 1 && rating <= 5
        ? Array(rating).fill('⭐').join('')
        : '—';
      return `> ${ratingIcons[category.key]} × **${category.label}:** \`${ratingStars}\``;
    })
    .join('\n');

  return new ContainerBuilder()
    .addSectionComponents(
      new SectionBuilder()
        .addTextDisplayComponents(
          text('## ```⭐ TWOJSERWER × OPINIA```\n')
        )
        .setThumbnailAccessory(new ThumbnailBuilder().setURL(authorAvatarUrl))
    )
    .addTextDisplayComponents(text(
      `> \`👤\` × **Twórca opinii:** <@${authorId}>\n` +
      `> \`📝\` × **Treść:** \`${content}\`\n\n` +
      ratingLines
    ));
}

async function incrementChannelSuffix(channel) {
  if (typeof channel.setName !== 'function') return;

  const match = /^(.*?)(?:-(\d+))?$/.exec(channel.name || '');
  const baseName = match[1] || channel.name || 'opinie';
  const nextCount = match[2] ? Number(match[2]) + 1 : 1;
  const nextName = `${baseName}-${nextCount}`;

  try {
    await channel.setName(nextName);
  } catch (error) {
    console.error(`[opinia] Nie udało się zmienić nazwy kanału na „${nextName}”:`, error);
  }
}

module.exports = {
  name: 'opinionCommandListener',

  async onSlashCommandInteraction(interaction) {
    if (interaction.commandName !== 'opinia') return;

    if (!interaction.guild) {
      return interaction.reply(statusPayload('❌ Tej komendy można używać tylko na serwerze.'));
    }

    pruneSessions();
    const session = newSession();
    sessions.set(sessionKey(interaction), session);

    await interaction.showModal(buildOpinionModal());
  },

  async onModalInteraction(interaction) {
    if (interaction.customId !== CONTENT_MODAL_ID) return;

    if (!interaction.guild) {
      return interaction.reply(statusPayload('❌ Wystąpił błąd — brak danych serwera.'));
    }

    const key = sessionKey(interaction);
    const session = sessions.get(key);
    if (!session) {
      return interaction.reply(statusPayload('⚠️ Sesja wygasła. Użyj ponownie komendy `/opinia`.'));
    }

    if (!TARGET_CHANNEL_ID) {
      return interaction.reply(statusPayload('❌ Nie skonfigurowano kanału docelowego (`OPINIA_TARGET_CHANNEL_ID` w `.env`).'));
    }

    const targetChannel = interaction.guild.channels.cache.get(TARGET_CHANNEL_ID);
    if (!targetChannel) {
      return interaction.reply(statusPayload('❌ Nie znaleziono kanału docelowego opinii. Sprawdź `OPINIA_TARGET_CHANNEL_ID` w `.env`.'));
    }

    const content = (interaction.fields.getTextInputValue(CONTENT_INPUT_ID) || '').trim() || 'Brak dodatkowej treści.';
    const ratings = Object.fromEntries(RATING_CATEGORIES.map(category => {
      const values = interaction.fields.getStringSelectValues(`${SELECT_PREFIX}:${category.key}`);
      return [category.key, values[0]];
    }));

    await interaction.deferReply({ flags: v2Flags(true) });

    try {
      await targetChannel.send({
        components: [buildOpinionContainer({
          authorId: interaction.user.id,
          authorAvatarUrl: interaction.user.displayAvatarURL(),
          ratings,
          content
        })],
        flags: v2Flags(false),
        allowedMentions: { parse: [] }
      });

      sessions.delete(key);

      await incrementChannelSuffix(targetChannel);

      if (interaction.message) {
        await interaction.message
          .edit(statusPayload('✅ Dziękujemy! Twoja opinia została wysłana.', { ephemeral: false }))
          .catch(() => {});
      }

      await interaction.editReply(
        statusPayload('✅ Twoja opinia została pomyślnie wysłana. Dziękujemy!', { ephemeral: false })
      );
    } catch (error) {
      console.error('[opinia] Nie udało się wysłać opinii:', error);
      await interaction.editReply(
        statusPayload('❌ Nie udało się wysłać opinii. Spróbuj ponownie później.', { ephemeral: false })
      );
    }
  }
};
