const {
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize
} = require('discord.js');

const SMALL_CAPS_CHANNEL_ID = process.env.SMALL_CAPS_CHANNEL_ID;
const MAX_OUTPUT_LENGTH = 1800;

const SMALL_CAPS_MAP = {
  a: 'ᴀ',
  b: 'ʙ',
  c: 'ᴄ',
  d: 'ᴅ',
  e: 'ᴇ',
  f: 'ғ',
  g: 'ɢ',
  h: 'ʜ',
  i: 'ɪ',
  j: 'ᴊ',
  k: 'ᴋ',
  l: 'ʟ',
  m: 'ᴍ',
  n: 'ɴ',
  o: 'ᴏ',
  p: 'ᴘ',
  q: 'ǫ',
  r: 'ʀ',
  s: 'ꜱ',
  t: 'ᴛ',
  u: 'ᴜ',
  v: 'ᴠ',
  w: 'ᴡ',
  x: 'х',
  y: 'ʏ',
  z: 'ᴢ',
  'ą': 'ᴀ',
  'ć': 'ᴄ',
  'ę': 'ᴇ',
  'ł': 'ʟ',
  'ń': 'ɴ',
  'ó': 'ᴏ',
  'ś': 'ꜱ',
  'ź': 'ᴢ',
  'ż': 'ᴢ'
};

function toSmallCaps(input) {
  return input
    .toLowerCase()
    .split('')
    .map(char => SMALL_CAPS_MAP[char] || char)
    .join('');
}

function separator() {
  return new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);
}

function buildResponse(originalText, smallCapsText) {
  return new ContainerBuilder()
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        "## GENERATOR SMALL CAPS"
      )
    )
    .addSeparatorComponents(separator())
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        "> Poniżej masz tekst przekonwertowany do formatu small caps\n" +
        "> Chcesz stworzyc własny? Wpisz odpowiedni wyraz, zdanie a zostanie ono wygenerowane!"
      )
    )
    .addSeparatorComponents(separator())
    .addTextDisplayComponents(
      new TextDisplayBuilder().setContent(
        `**Tekst do skopiowania:**\n\`\`\`text\n${smallCapsText}\n\`\`\``
      )
    );
}

module.exports = {
  name: 'smallCapsGeneratorListener',

  async onMessageCreate(message) {
    if (!SMALL_CAPS_CHANNEL_ID) return;
    if (message.author.bot) return;
    if (message.channel.id !== SMALL_CAPS_CHANNEL_ID) return;

    const originalText = message.content.trim();
    if (!originalText) return;

    const smallCapsText = toSmallCaps(originalText);
    if (smallCapsText.length > MAX_OUTPUT_LENGTH) {
      await message.channel.send({
        content: "❌ Ten tekst jest za długi do wygenerowania small caps. Skróć wiadomość i spróbuj ponownie."
      });
      return;
    }

    await message.channel.send({
      components: [buildResponse(originalText, smallCapsText)],
      flags: MessageFlags.IsComponentsV2
    });
  }
};
