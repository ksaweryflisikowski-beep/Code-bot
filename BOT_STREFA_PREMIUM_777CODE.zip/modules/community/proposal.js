const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  AttachmentBuilder,
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SectionBuilder,
  ThumbnailBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder,
  ChannelType,
  PermissionFlagsBits
} = require('discord.js');
const path = require('path');
const fs = require('fs');

const PROPOSAL_CHANNEL_ID = process.env.PROPOSAL_CHANNEL_ID;
const PROPOSAL_ACCEPT_EMOJI_ID = process.env.PROPOSAL_ACCEPT_EMOJI_ID;
const PROPOSAL_REJECT_EMOJI_ID = process.env.PROPOSAL_REJECT_EMOJI_ID;

const upvotedMessages = new Set();
const downvotedMessages = new Set();
const proposals = new Map();

function getBannerAttachment() {
  const bannerPath = path.join(__dirname, '..', '..', 'banner.png');
  if (fs.existsSync(bannerPath)) {
    return new AttachmentBuilder(bannerPath, { name: 'banner.png' });
  }
  return null;
}

function buildProposalMessage(authorMention, authorAvatarUrl, content, upvotesCount, downvotesCount, withBanner = true) {
  const totalVotes = upvotesCount + downvotesCount;
  const upvotePercent = totalVotes === 0 ? 0 : Math.round((upvotesCount * 100) / totalVotes);
  const downvotePercent = totalVotes === 0 ? 0 : Math.round((downvotesCount * 100) / totalVotes);

  const upvoteBtn = new ButtonBuilder()
    .setCustomId('proposal:upvote')
    .setLabel(`${upvotesCount} (${upvotePercent}%)`)
    .setStyle(ButtonStyle.Secondary)
    .setEmoji({ id: PROPOSAL_ACCEPT_EMOJI_ID, name: 'tak' });

  const downvoteBtn = new ButtonBuilder()
    .setCustomId('proposal:downvote')
    .setLabel(`${downvotesCount} (${downvotePercent}%)`)
    .setStyle(ButtonStyle.Secondary)
    .setEmoji({ id: PROPOSAL_REJECT_EMOJI_ID, name: 'nie' });

  const row = new ActionRowBuilder().addComponents(upvoteBtn, downvoteBtn);

  const formattedContent = content.split('\n').map(line => `> ${line}`).join('\n');
  const voteSummary =
    `> **Status:** Głosowanie otwarte\n` +
    `> **Wynik:** ${upvotesCount} za / ${downvotesCount} przeciw\n` +
    `> **Dyskusja:** napisz swoją opinię w wątku pod propozycją.`;

  const banner = withBanner ? getBannerAttachment() : null;

  const container = new ContainerBuilder();

  if (withBanner && banner) {
    container.addMediaGalleryComponents(
      new MediaGalleryBuilder().addItems(
        new MediaGalleryItemBuilder().setURL('attachment://banner.png')
      )
    );
  }

  container.addSectionComponents(
    new SectionBuilder()
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(`## NOWA PROPOZYCJA\n**Autor:** ${authorMention}`)
      )
      .setThumbnailAccessory(new ThumbnailBuilder().setURL(authorAvatarUrl))
  );

  container
    .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(voteSummary))
    .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
    .addTextDisplayComponents(new TextDisplayBuilder().setContent(`**Treść propozycji:**\n${formattedContent}`))
    .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
    .addActionRowComponents(row);

  return {
    components: [container],
    files: banner ? [banner] : [],
    flags: MessageFlags.IsComponentsV2
  };
}

async function createProposalThread(proposalMessage, threadTitle) {
  const { channel, guild } = proposalMessage;

  if (!channel || ![ChannelType.GuildText, ChannelType.GuildAnnouncement].includes(channel.type)) {
    console.error('Nie można utworzyć wątku propozycji: kanał propozycji musi być kanałem tekstowym lub ogłoszeniowym.');
    return null;
  }

  const botPermissions = channel.permissionsFor(guild?.members.me);
  if (!botPermissions?.has(PermissionFlagsBits.CreatePublicThreads)) {
    console.error('Nie można utworzyć wątku propozycji: bot nie ma uprawnienia Create Public Threads na kanale propozycji.');
    return null;
  }

  try {
    return await proposalMessage.startThread({
      name: threadTitle,
      autoArchiveDuration: 1440,
      reason: 'Nowa propozycja'
    });
  } catch (err) {
    console.error('Nie udało się utworzyć wątku pod wiadomością propozycji:', err);
    return null;
  }
}

module.exports = {
  name: 'proposalEventListener',

  async onMessageCreate(message) {
    if (message.author.bot || message.channel.id !== PROPOSAL_CHANNEL_ID) {
      return;
    }

    const content = message.content;
    const author = message.member || message.author;

    await message.delete().catch(() => {});

    if (!author || !content || content.trim().length === 0) return;

    const authorMention = `<@${author.id}>`;
    const authorAvatarUrl = message.author.displayAvatarURL();

    const proposalMessage = await message.channel.send({
      content: '\u200B',
      allowedMentions: { parse: [] },
    });

    let threadTitle = `Dyskusja - Propozycja ${message.author.username}`;
    if (threadTitle.length > 100) {
      threadTitle = threadTitle.substring(0, 97) + "...";
    }

    const thread = await createProposalThread(proposalMessage, threadTitle);
    if (!thread) {
      await proposalMessage.delete().catch(() => {});
      return;
    }

    const msgPayload = buildProposalMessage(authorMention, authorAvatarUrl, content, 0, 0);
    await proposalMessage.edit({
      ...msgPayload,
      content: null,
      allowedMentions: { parse: [] }
    });

    proposals.set(proposalMessage.id, {
      authorMention,
      authorAvatarUrl,
      content
    });
  },

  async onButtonInteraction(interaction) {
    const { customId, message, user } = interaction;

    if (customId !== 'proposal:upvote' && customId !== 'proposal:downvote') {
      return;
    }

    const messageId = message.id;
    const userId = user.id;
    const voteKey = `${messageId}:${userId}`;

    const data = proposals.get(messageId);
    if (!data) {
      const container = new ContainerBuilder()
        .addTextDisplayComponents(
          new TextDisplayBuilder().setContent(
            "Nie mogę zaktualizować tej propozycji (brak zapisanych danych, np. po restarcie bota)."
          )
        );

      return interaction.reply({
        components: [container],
        flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
      });
    }

    const isUpvote = customId === 'proposal:upvote';

    if (isUpvote) {
      if (upvotedMessages.has(voteKey)) {
        upvotedMessages.delete(voteKey);
      } else {
        upvotedMessages.add(voteKey);
        downvotedMessages.delete(voteKey);
      }
    } else {
      if (downvotedMessages.has(voteKey)) {
        downvotedMessages.delete(voteKey);
      } else {
        downvotedMessages.add(voteKey);
        upvotedMessages.delete(voteKey);
      }
    }

    let upvotesCount = 0;
    for (const key of upvotedMessages) {
      if (key.startsWith(`${messageId}:`)) upvotesCount++;
    }

    let downvotesCount = 0;
    for (const key of downvotedMessages) {
      if (key.startsWith(`${messageId}:`)) downvotesCount++;
    }

    const hasBanner = message.attachments.some(att => att.name === 'banner.png');
    const updatedPayload = buildProposalMessage(
      data.authorMention,
      data.authorAvatarUrl,
      data.content,
      upvotesCount,
      downvotesCount,
      hasBanner
    );

    await interaction.update({
      components: updatedPayload.components,
      flags: MessageFlags.IsComponentsV2,
      allowedMentions: { parse: [] }
    });
  }
};
