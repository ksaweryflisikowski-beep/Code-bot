const {
  ActivityType,
  ContainerBuilder,
  EmbedBuilder,
  MessageFlags,
  PermissionsBitField,
  TextDisplayBuilder
} = require('discord.js');
const fs = require('fs');
const path = require('path');

const STATUS_ROLE_ID = process.env.STATUS_ROLE_ID;
const MODERATION_LOG_CHANNEL_ID = process.env.MODERATION_LOG_CHANNEL_ID;
const HISTORY_PATH = path.join(__dirname, '..', '..', 'data', 'status_history.json');
const REQUIRED_STATUS = [
  'discord.gg/twojserwer',
  'dc.gg/twojserwer',
  'dc.twojserwer.pl',
  '.gg/twojeserwer'
];

let history = {};
try {
  if (fs.existsSync(HISTORY_PATH)) {
    history = JSON.parse(fs.readFileSync(HISTORY_PATH, 'utf8'));
  }
} catch (error) {
  console.error('Nie udało się odczytać historii statusów:', error);
  throw error;
}

let saveQueue = Promise.resolve();
const memberQueues = new Map();

function v2Reply(content, { allowedMentions = { parse: [] }, ephemeral = true } = {}) {
  return {
    components: [new ContainerBuilder().addTextDisplayComponents(
      new TextDisplayBuilder().setContent(content)
    )],
    flags: ephemeral
      ? (MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral)
      : MessageFlags.IsComponentsV2,
    allowedMentions
  };
}

function saveHistory() {
  const snapshot = JSON.stringify(history, null, 2);
  saveQueue = saveQueue.catch(() => {}).then(async () => {
    const tempPath = `${HISTORY_PATH}.tmp`;
    await fs.promises.writeFile(tempPath, snapshot, 'utf8');
    await fs.promises.rename(tempPath, HISTORY_PATH);
  });
  return saveQueue;
}

function historyFor(guildId, userId) {
  if (!history[guildId]) history[guildId] = {};
  if (!history[guildId][userId]) history[guildId][userId] = [];
  return history[guildId][userId];
}

function customStatusMatches(presence) {
  if (!presence || presence.status === 'offline') return false;

  return presence.activities.some(activity => {
    if (activity.type !== ActivityType.Custom || !activity.state) return false;
    const state = activity.state.toLowerCase();
    return REQUIRED_STATUS.some(required => state.includes(required));
  });
}

function queueMemberUpdate(guildId, userId, operation) {
  const key = `${guildId}:${userId}`;
  const previous = memberQueues.get(key) || Promise.resolve();
  const current = previous
    .then(operation)
    .catch(error => console.error(`Nie udało się zaktualizować statusu użytkownika ${userId}:`, error))
    .finally(() => {
      if (memberQueues.get(key) === current) memberQueues.delete(key);
    });
  memberQueues.set(key, current);
}

async function sendRoleLog(guild, member, granted) {
  if (!MODERATION_LOG_CHANNEL_ID) {
    throw new Error('Brak MODERATION_LOG_CHANNEL_ID w pliku .env.');
  }

  const channel = guild.channels.cache.get(MODERATION_LOG_CHANNEL_ID)
    || await guild.channels.fetch(MODERATION_LOG_CHANNEL_ID);
  if (!channel?.isTextBased() || typeof channel.send !== 'function') {
    throw new Error(`Kanał logów ${MODERATION_LOG_CHANNEL_ID} nie jest kanałem tekstowym.`);
  }

  const embed = new EmbedBuilder()
    .setColor(granted ? 0x57F287 : 0xED4245)
    .setTitle(granted ? 'Nadano rolę za status' : 'Usunięto rolę za status')
    .addFields(
      { name: 'Użytkownik', value: `<@${member.id}> (\`${member.id}\`)` },
      { name: 'Rola', value: `<@&${STATUS_ROLE_ID}> (\`${STATUS_ROLE_ID}\`)` }
    )
    .setTimestamp();

  await channel.send({ embeds: [embed], allowedMentions: { parse: [] } });
}

async function updateMemberStatus(guild, userId, qualifies) {
  if (!STATUS_ROLE_ID) throw new Error('Brak STATUS_ROLE_ID w pliku .env.');

  const member = await guild.members.fetch(userId).catch(error => {
    if (error.code !== 10007) throw error;
    return null;
  });
  if (!member) return;

  const role = guild.roles.cache.get(STATUS_ROLE_ID);
  if (!role) throw new Error(`Nie znaleziono roli statusu ${STATUS_ROLE_ID} na serwerze ${guild.id}.`);

  const intervals = historyFor(guild.id, userId);
  const openInterval = intervals.find(interval => !interval.endedAt);
  const hasRole = member.roles.cache.has(STATUS_ROLE_ID);

  if (qualifies) {
    if (!hasRole) {
      await member.roles.add(role, 'Użytkownik ustawił wymagany status Discorda');
      await sendRoleLog(guild, member, true).catch(error =>
        console.error('Nie udało się wysłać logu nadania roli statusu:', error)
      );
    }
    if (!openInterval) {
      intervals.push({ startedAt: new Date().toISOString(), endedAt: null });
      await saveHistory();
    }
    return;
  }

  if (openInterval) {
    openInterval.endedAt = new Date().toISOString();
    await saveHistory();
  }
  if (hasRole) {
    await member.roles.remove(role, 'Użytkownik usunął wymagany status lub jest offline');
    await sendRoleLog(guild, member, false).catch(error =>
      console.error('Nie udało się wysłać logu usunięcia roli statusu:', error)
    );
  }
}

function handlePresenceUpdate(_oldPresence, newPresence) {
  const guild = newPresence?.guild || _oldPresence?.guild;
  const userId = newPresence?.userId || _oldPresence?.userId;
  if (!guild || !userId) return;

  queueMemberUpdate(guild.id, userId, () =>
    updateMemberStatus(guild, userId, customStatusMatches(newPresence))
  );
}

module.exports = {
  name: 'statusCommandListener',

  onPresenceUpdate: handlePresenceUpdate,

  onGuildMemberRemove(member) {
    queueMemberUpdate(member.guild.id, member.id, async () => {
      const intervals = history[member.guild.id]?.[member.id] || [];
      const openInterval = intervals.find(interval => !interval.endedAt);
      if (!openInterval) return;

      openInterval.endedAt = new Date().toISOString();
      await saveHistory();
    });
  },

  async onSlashCommandInteraction(interaction) {
    if (interaction.commandName === 'status_panel') {
      if (!interaction.member?.permissions.has(PermissionsBitField.Flags.Administrator)) {
        return interaction.reply(v2Reply('❌ Tylko administrator może wysłać panel statusu.'));
      }
      if (!STATUS_ROLE_ID) {
        return interaction.reply(v2Reply('❌ Nie skonfigurowano `STATUS_ROLE_ID` w pliku `.env`.'));
      }

      const panel = new ContainerBuilder()
        .addTextDisplayComponents(new TextDisplayBuilder().setContent(
          '# ROLA ZA STATUS\n' +
          'Ustaw status na swoim profilu Discord, aby otrzymać rolę <@&' + STATUS_ROLE_ID + '>.\n\n' +
          '**JAK USTAWIC STATUS?**\n' +
          '1. Kliknij swoje zdjęcie profilowe w Discordzie.\n' +
          '2. Wybierz **Ustaw status niestandardowy** lub **Dodaj status**.\n' +
          '3. Wpisz w treści statusu jeden z poniższych tekstów:\n' +
          '・ `discord.gg/twojserwer`\n' +
          '・ `dc.gg/twojserwer`\n' +
          '・ `dc.twojserwer.pl`\n' +
          '・ `.gg/twojeserwer`\n' +
          '4. W polu **Wyczyść po...** wybierz opcje **Nie czyść**.\n' +
          '5. Kliknij **Zapisz**.\n' +
          '6. Gotowe! Jeśli spełniasz wymagania, bot nada Ci rolę automatycznie.\n\n' +
          '## WAŻNE:\n' +
          'Aby bot wykrył twój status, nie możesz być\n' +
          'Niewidoczny. Ustaw swój status na dostępny lub nie przeszkadzac!\n\n' +
          '## CO DAJE ROLA <@&' + STATUS_ROLE_ID + '> ?\n' +
          '・ Dostęp do czatu premium\n' +
          '・ Dostęp do konkursów premium\n' +
          '・ Unikalna rangę\n' +
          '・ Możliwość wysyłania gifów'
        ));

      await interaction.channel.send({
        components: [panel],
        flags: MessageFlags.IsComponentsV2,
        allowedMentions: { parse: [] }
      });
      return interaction.reply(v2Reply('✅ Panel statusu został wysłany.'));
    }

    if (interaction.commandName !== 'historia_status') return;
    if (!interaction.guild) {
      return interaction.reply(v2Reply('❌ Tej komendy można używać tylko na serwerze.'));
    }
    if (!interaction.member?.permissions.has(PermissionsBitField.Flags.Administrator)) {
      return interaction.reply(v2Reply('❌ Tylko administrator może sprawdzać historię statusu.'));
    }

    const target = interaction.options.getUser('uzytkownik', true);
    const intervals = history[interaction.guild.id]?.[target.id] || [];
    if (intervals.length === 0) {
      return interaction.reply(v2Reply(
        `## HISTORIA STATUSU: <@${target.id}>\n\nBrak historii ustawienia wymaganego statusu.`,
        { allowedMentions: { users: [target.id] } }
      ));
    }

    const records = intervals.slice(-20).reverse().map((interval, index) => {
      const start = Math.floor(new Date(interval.startedAt).getTime() / 1000);
      const end = interval.endedAt
        ? `<t:${Math.floor(new Date(interval.endedAt).getTime() / 1000)}:F>`
        : '**nadal aktywny**';
      return `**${intervals.length - index}.** Od: <t:${start}:F>\nDo: ${end}`;
    });
    const olderRecords = intervals.length > 20
      ? `\n\n_Pokazano 20 najnowszych z ${intervals.length} okresów._`
      : '';

    return interaction.reply(v2Reply(
      `## HISTORIA STATUSU: <@${target.id}>\n\n${records.join('\n\n')}${olderRecords}`,
      { allowedMentions: { users: [target.id] } }
    ));
  }
};
