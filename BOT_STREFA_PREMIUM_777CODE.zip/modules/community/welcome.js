const {
  AttachmentBuilder,
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder
} = require('discord.js');
const path = require('path');
const fs = require('fs');

const WELCOME_CHANNEL_ID = process.env.WELCOME_CHANNEL_ID;

module.exports = {
  name: 'welcomeEventListener',

  async onGuildMemberAdd(member) {
    const guild = member.guild;
    const welcomeChannel = guild.channels.cache.get(WELCOME_CHANNEL_ID);

    if (!welcomeChannel) return;

    const bannerPath = path.join(__dirname, '..', '..', 'banner.png');
    const files = [];

    if (fs.existsSync(bannerPath)) {
      files.push(new AttachmentBuilder(bannerPath, { name: 'banner.png' }));
    }

    const container = new ContainerBuilder();

    if (files.length > 0) {
      container.addMediaGalleryComponents(
        new MediaGalleryBuilder().addItems(
          new MediaGalleryItemBuilder().setURL('attachment://banner.png')
        )
      );
    }

    container
      .addTextDisplayComponents(new TextDisplayBuilder().setContent("## LOBBY - TwojSerwer"))
      .addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small))
      .addTextDisplayComponents(
        new TextDisplayBuilder().setContent(
          `> Witaj <@${member.id}>!\n\n` +
          `> Właśnie dołączyłeś na **oficjalny serwer** discord **TwojSerwer**.\n` +
          `> Mamy nadzieję, że zostaniesz z nami na dłużej!\n\n` +
          `> Jesteś **${guild.memberCount} osobą** na naszym serwerze!`
        )
      );

    await welcomeChannel.send({
      components: [container],
      files,
      flags: MessageFlags.IsComponentsV2
    });
  }
};
