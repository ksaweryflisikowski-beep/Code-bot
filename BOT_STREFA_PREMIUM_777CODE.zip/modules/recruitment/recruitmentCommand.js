const {
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  AttachmentBuilder,
  PermissionsBitField,
  ChannelType,
  MessageFlags,
  ContainerBuilder,
  TextDisplayBuilder,
  SeparatorBuilder,
  SeparatorSpacingSize,
  SectionBuilder,
  ThumbnailBuilder,
  MediaGalleryBuilder,
  MediaGalleryItemBuilder
} = require('discord.js');
const path = require('path');
const fs = require('fs');

const COLORS = {
  main: 0x5865F2,
  success: 0x57F287,
  error: 0xED4245,
  warn: 0xFEE75C
};


function v2Flags(ephemeral = false) {
  return ephemeral
    ? (MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral)
    : MessageFlags.IsComponentsV2;
}

function text(content) {
  return new TextDisplayBuilder().setContent(content);
}

function separator() {
  return new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small);
}

function buildContainer({ title, description, banner = false, avatar = null, note = null, rows = [] }) {
  const container = new ContainerBuilder();

  if (banner) {
    container.addMediaGalleryComponents(
      new MediaGalleryBuilder().addItems(
        new MediaGalleryItemBuilder().setURL('attachment://banner.png')
      )
    );
  }

  if (title) {
    if (avatar) {
      container.addSectionComponents(
        new SectionBuilder()
          .addTextDisplayComponents(text(`## ${title}`))
          .setThumbnailAccessory(new ThumbnailBuilder().setURL(avatar))
      );
    } else {
      container.addTextDisplayComponents(text(`## ${title}`));
    }
  }
  if (title && description) container.addSeparatorComponents(separator());
  if (description) container.addTextDisplayComponents(text(description));

  if (note) {
    container.addSeparatorComponents(separator());
    container.addTextDisplayComponents(text(note));
  }

  if (rows.length > 0) {
    container.addSeparatorComponents(separator());
    container.addActionRowComponents(...rows);
  }

  return container;
}

function statusPayload(content, { color = COLORS.main, ephemeral = false } = {}) {
  const container = new ContainerBuilder()
    .addTextDisplayComponents(text(content));
  return { components: [container], flags: v2Flags(ephemeral) };
}

const errorReply = (content) => statusPayload(content, { color: COLORS.error, ephemeral: true });
const successReply = (content) => statusPayload(content, { color: COLORS.success, ephemeral: true });


function getBannerUpload() {
  const bannerPath = path.join(__dirname, '..', '..', 'banner.png');
  if (fs.existsSync(bannerPath)) {
    return new AttachmentBuilder(bannerPath, { name: 'banner.png' });
  }
  return null;
}

function getRoleIcon(role) {
  switch (role) {
    case "Support": return "👤";
    case "Montażysta": return "📽️";
    case "Java Developer": return "🖥️";
    case "Grafik": return "🎨";
    case "Budowniczy": return "🧱";
    case "Pack Creator": return "📦";
    case "Web Developer": return "🌐";
    case "Tester": return "🔎";
    case "Bot Developer": return "🤖";
    case "Script Developer": return "🔧";
    case "Premium Creator": return "☀️";
    default: return "📝";
  }
}

function getRoleId(role) {
  switch (role) {
    case "Support": return process.env.SUPPORT_ROLE_ID;
    case "Montażysta": return process.env.MONTAZYSTA_ROLE_ID;
    case "Java Developer": return process.env.JAVA_DEV_ROLE_ID;
    case "Grafik": return process.env.GRAFIK_ROLE_ID;
    case "Budowniczy": return process.env.BUDOWNICZY_ROLE_ID;
    case "Pack Creator": return process.env.PACK_CREATOR_ROLE_ID;
    case "Web Developer": return process.env.WEB_DEV_ROLE_ID;
    case "Tester": return process.env.TESTER_ROLE_ID;
    case "Bot Developer": return process.env.BOT_DEV_ROLE_ID;
    case "Script Developer": return process.env.SCRIPT_DEV_ROLE_ID;
    case "Premium Creator": return process.env.PREMIUM_CREATOR_ROLE_ID;
    default: return null;
  }
}

module.exports = {
  name: 'recruitmentCommandListener',

  async onSlashCommandInteraction(interaction) {
    if (interaction.commandName !== 'rekrutacja_panel') return;

    const banner = getBannerUpload();

    const menu = new StringSelectMenuBuilder()
      .setCustomId('rekrutacja:stanowisko')
      .setPlaceholder('Wybierz stanowisko...')
      .addOptions([
        { label: '👤 Support', value: 'Support' },
        { label: '📽️ Montażysta', value: 'Montażysta' },
        { label: '🖥️ Java Developer', value: 'Java Developer' },
        { label: '🎨 Grafik', value: 'Grafik' },
        { label: '🧱 Budowniczy', value: 'Budowniczy' },
        { label: '📦 Pack Creator', value: 'Pack Creator' },
        { label: '🌐 Web Developer', value: 'Web Developer' },
        { label: '🔎 Tester', value: 'Tester' },
        { label: '🤖 Bot Developer', value: 'Bot Developer' },
        { label: '🔧 Script Developer', value: 'Script Developer' },
        { label: '☀️ Premium Creator', value: 'Premium Creator' }
      ]);

    const row = new ActionRowBuilder().addComponents(menu);

    const container = buildContainer({
      title: "REKRUTACJA",
      description:
        "Dołącz do zespołu **TwojSerwer**!\n" +
        "Poszukujemy pasjonatów, którzy pomogą nam tworzyć i rozwijać nasz projekt.\n" +
        "Jeśli chcesz zajmować się np. __moderacją__, __tworzeniem treści__,\n" +
        "__grafiką__ czy __wsparciem graczy__, dołącz do nas i zyskaj realny wpływ\n" +
        "na to, co budujemy. Wybierz stanowisko poniżej i zobacz szczegóły!\n\n" +
        "### Dostępne stanowiska:\n\n" +
        "👤 `➜` **Support**\n" +
        "📽️ `➜` **Montażysta**\n" +
        "🖥️ `➜` **Java Developer**\n" +
        "🎨 `➜` **Grafik**\n" +
        "🧱 `➜` **Budowniczy**\n" +
        "📦 `➜` **Pack Creator**\n" +
        "🌐 `➜` **Web Developer**\n" +
        "🔎 `➜` **Tester**\n" +
        "🔧 `➜` **Script Developer**\n" +
        "🤖 `➜` **Bot Developer**\n" +
        "☀️ `➜` **Premium Creator**\n",
      banner: !!banner,
      rows: [row]
    });

    await interaction.channel.send({
      components: [container],
      files: banner ? [banner] : [],
      flags: v2Flags()
    });

    await interaction.reply(successReply("✅ Panel rekrutacji został pomyślnie wysłany!"));
  },

  async onStringSelectInteraction(interaction) {
    if (interaction.customId !== 'rekrutacja:stanowisko') return;

    const chosenRole = interaction.values[0];
    const roleId = getRoleId(chosenRole);
    const roleMention = roleId ? `<@&${roleId}>` : `**${chosenRole}**`;

    const applyButton = new ButtonBuilder()
      .setCustomId(`rekrutacja:aplikuj:${chosenRole}`)
      .setLabel('✅ Akceptuję Regulamin Rekrutacji')
      .setStyle(ButtonStyle.Secondary);

    const row = new ActionRowBuilder().addComponents(applyButton);
    const banner = getBannerUpload();

    const container = buildContainer({
      title: "REKRUTACJA",
      description:
        `> Rekrutacja na stanowisko: ${roleMention}\n` +
        `> Jeżeli spełniasz wymagania i chcesz\n` +
        `> kontynuować, kliknij **Akceptuję Regulamin Rekrutacji**.`,
      banner: !!banner,
      rows: [row]
    });

    await interaction.reply({
      components: [container],
      files: banner ? [banner] : [],
      flags: v2Flags(true)
    });
  },

  async onButtonInteraction(interaction) {
    const { customId, channel, user } = interaction;

    if (customId.startsWith("rekrutacja:aplikuj:")) {
      const chosenRole = customId.replace("rekrutacja:aplikuj:", "");

      const ageInput = new TextInputBuilder()
        .setCustomId('rekrutacja:wiek')
        .setLabel('Twój wiek')
        .setPlaceholder('np. 18')
        .setStyle(TextInputStyle.Short)
        .setMinLength(1)
        .setMaxLength(3)
        .setRequired(true);

      const expInput = new TextInputBuilder()
        .setCustomId('rekrutacja:doswiadczenie')
        .setLabel('Doświadczenie')
        .setPlaceholder('Opisz swoje doświadczenie...')
        .setStyle(TextInputStyle.Paragraph)
        .setMaxLength(1000)
        .setRequired(true);

      const reasonInput = new TextInputBuilder()
        .setCustomId('rekrutacja:dlaczego')
        .setLabel('Dlaczego Ty?')
        .setPlaceholder('Napisz, dlaczego to właśnie Ciebie powinniśmy wybrać...')
        .setStyle(TextInputStyle.Paragraph)
        .setMaxLength(1000)
        .setRequired(true);

      const modal = new ModalBuilder()
        .setCustomId(`rekrutacja:modal:${chosenRole}`)
        .setTitle(`Rekrutacja - ${chosenRole}`)
        .addComponents(
          new ActionRowBuilder().addComponents(ageInput),
          new ActionRowBuilder().addComponents(expInput),
          new ActionRowBuilder().addComponents(reasonInput)
        );

      await interaction.showModal(modal);
      return;
    }

    if (customId.startsWith("rekrutacja:akceptuj:")) {
      await interaction.reply(
        statusPayload(`✅ Podanie zostało **Zaakceptowane** przez <@${user.id}>!`, { color: COLORS.success })
      );
    } else if (customId.startsWith("rekrutacja:odrzuc:")) {
      await interaction.reply(
        statusPayload(`❌ Podanie zostało **Odrzucone** przez <@${user.id}>!`, { color: COLORS.error })
      );
    } else if (customId.startsWith("rekrutacja:zamknij:")) {
      await interaction.reply(
        statusPayload(`🔒 Podanie zostało **zamknięte** przez <@${user.id}>`, { color: COLORS.warn })
      );
      setTimeout(() => {
        channel.delete().catch(() => {});
      }, 5000);
    }
  },

  async onModalInteraction(interaction) {
    if (!interaction.customId.startsWith("rekrutacja:modal:")) return;

    const chosenRole = interaction.customId.replace("rekrutacja:modal:", "");
    const { guild, member } = interaction;

    if (!guild || !member) {
      return interaction.reply(errorReply("❌ Wystąpił błąd podczas pobierania danych serwera."));
    }

    const age = interaction.fields.getTextInputValue('rekrutacja:wiek') || "Brak";
    const experience = interaction.fields.getTextInputValue('rekrutacja:doswiadczenie') || "Brak";
    const reason = interaction.fields.getTextInputValue('rekrutacja:dlaczego') || "Brak";

    const icon = getRoleIcon(chosenRole);
    const channelRoleName = chosenRole.toLowerCase().replace(/ /g, "_");
    const channelName = `${icon}・${channelRoleName}-${interaction.user.username}`;

    const categoryId = process.env.RECRUITMENT_CATEGORY_ID;

    try {
      const createdChannel = await guild.channels.create({
        name: channelName,
        type: ChannelType.GuildText,
        parent: categoryId,
        permissionOverwrites: [
          {
            id: guild.roles.everyone.id,
            deny: [PermissionsBitField.Flags.ViewChannel]
          },
          {
            id: member.id,
            allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages]
          }
        ]
      });

      await interaction.reply(
        successReply(`**Twoje podanie zostało utworzone!** Przejdź do kanału: <#${createdChannel.id}>`)
      );

      const roleId = getRoleId(chosenRole);
      const roleMention = roleId ? `<@&${roleId}>` : `**${chosenRole}**`;

      const acceptBtn = new ButtonBuilder().setCustomId(`rekrutacja:akceptuj:${member.id}`).setLabel("✅ Zaakceptuj").setStyle(ButtonStyle.Success);
      const rejectBtn = new ButtonBuilder().setCustomId(`rekrutacja:odrzuc:${member.id}`).setLabel("❌ Odrzuć").setStyle(ButtonStyle.Danger);
      const closeBtn = new ButtonBuilder().setCustomId(`rekrutacja:zamknij:${member.id}`).setLabel("🔒 Zamknij").setStyle(ButtonStyle.Secondary);

      const row = new ActionRowBuilder().addComponents(acceptBtn, rejectBtn, closeBtn);
      const banner = getBannerUpload();

      const container = buildContainer({
        title: `PODANIE - ${chosenRole.toUpperCase()}`,
        description:
          `**Aplikant:** <@${member.id}>\n` +
          `**Stanowisko:** ${roleMention}\n\n` +
          `**Wiek:** \`${age}\`\n` +
          `**Doświadczenie:** \`${experience}\`\n` +
          `**Dlaczego ty?:** \`${reason}\``,
        avatar: member.displayAvatarURL({ extension: 'png', size: 128 }),
        note:
          `Dziękujemy za złożenie podania! Administracja zapozna się z nim\n` +
          `w najbliższym czasie. Prosimy o cierpliwość i nie pingowanie nas!\n` +
          `Powodzenia!`,
        banner: !!banner,
        rows: [row]
      });

      if (roleId) {
        const pingMsg = await createdChannel.send({
          components: [text(`<@&${roleId}>`)],
          flags: v2Flags()
        });
        await pingMsg.delete().catch(() => {});
      }

      await createdChannel.send({
        components: [container],
        files: banner ? [banner] : [],
        flags: v2Flags()
      });

    } catch (err) {
      console.error(err);
      const payload = errorReply("❌ Błąd podczas tworzenia kanału rekrutacji.");
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(payload).catch(() => {});
      } else {
        await interaction.reply(payload).catch(() => {});
      }
    }
  }
};
