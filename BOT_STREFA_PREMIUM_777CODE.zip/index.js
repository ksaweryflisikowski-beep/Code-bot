require('dotenv').config();
const {
  Client,
  ChannelType,
  GatewayIntentBits,
  Partials,
  REST,
  Routes,
  SlashCommandBuilder,
  PermissionsBitField
} = require('discord.js');

const client = new Client({
  partials: [Partials.Message],
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildPresences
  ]
});

const drop = require('./modules/commerce/drop.js');
const legitCheck = require('./modules/commerce/legitCheck.js');
const statusModule = require('./modules/community/status.js');
const giveawayModule = require('./modules/community/giveaway.js');
const adminCommands = require('./modules/moderation/adminCommands.js');
const registerAuditLogs = require('./modules/moderation/auditLogs.js');

const modules = [
  require('./modules/moderation/antiInvite.js'),
  adminCommands,
  legitCheck,
  require('./modules/community/proposal.js'),
  statusModule,
  giveawayModule,
  require('./modules/community/opinionCommand.js'),
  require('./modules/recruitment/recruitmentCommand.js'),
  require('./modules/verification/screenShotVerification.js'),
  require('./modules/community/smallCapsGenerator.js'),
  require('./modules/commerce/tickets.js'),
  drop,
  require('./modules/verification/verification.js'),
  require('./modules/community/welcome.js'),
  require('./modules/community/welcomeDm.js'),
  require('./modules/community/botPresence.js')
];

const commands = [
  new SlashCommandBuilder().setName('rekrutacja_panel').setDescription('Wysyła panel rekrutacji'),
  new SlashCommandBuilder().setName('ticket_panel').setDescription('Wysyła panel ticketów'),
  new SlashCommandBuilder().setName('weryfikacja_panel').setDescription('Wysyła panel weryfikacji'),
  new SlashCommandBuilder()
    .setName('opinia')
    .setDescription('Wystaw opinię o naszych usługach')
    .setDMPermission(false),
  new SlashCommandBuilder()
    .setName('status_panel')
    .setDescription('Wysyła panel informacji o roli za status Discorda')
    .setDMPermission(false),
  new SlashCommandBuilder()
    .setName('historia_status')
    .setDescription('Sprawdza historię statusu użytkownika')
    .setDMPermission(false)
    .addUserOption(opt => opt.setName('uzytkownik').setDescription('Użytkownik do sprawdzenia').setRequired(true)),
  new SlashCommandBuilder()
    .setName('konkurs')
    .setDescription('Tworzy konkurs z losowaniem zwycięzców')
    .setDMPermission(false)
    .addStringOption(opt => opt.setName('nagroda').setDescription('Nagroda w konkursie').setRequired(true).setMaxLength(200))
    .addStringOption(opt => opt.setName('czas').setDescription('Czas trwania, np. 30m, 2h lub 7d').setRequired(true).setMaxLength(10))
    .addIntegerOption(opt => opt.setName('zwyciezcy').setDescription('Liczba zwycięzców (1-20)').setRequired(true).setMinValue(1).setMaxValue(20))
    .addChannelOption(opt => opt.setName('kanal').setDescription('Kanał publikacji (domyślnie bieżący)').addChannelTypes(ChannelType.GuildText))
    .addStringOption(opt => opt.setName('opis').setDescription('Dodatkowe informacje o konkursie').setMaxLength(1000)),
  new SlashCommandBuilder()
    .setName('reroll')
    .setDescription('Losuje ponownie zwycięzców zakończonego konkursu')
    .setDMPermission(false)
    .addStringOption(opt => opt.setName('id_wiadomosci').setDescription('ID wiadomości konkursowej').setRequired(true).setMinLength(17).setMaxLength(20)),
  new SlashCommandBuilder()
    .setName('adduser')
    .setDescription('Dodaje użytkownika do ticketa')
    .addUserOption(opt => opt.setName('user').setDescription('Użytkownik do dodania').setRequired(true)),
  new SlashCommandBuilder()
    .setName('removeuser')
    .setDescription('Usuwa użytkownika z ticketa')
    .addUserOption(opt => opt.setName('user').setDescription('Użytkownik do usunięcia').setRequired(true)),
  new SlashCommandBuilder().setName('zamknij').setDescription('Zamyka obecny ticket'),
  new SlashCommandBuilder()
    .setName('wezwij')
    .setDescription('Wzywa właściciela ticketa na kanał')
    .setDMPermission(false),
  new SlashCommandBuilder().setName('przejmij').setDescription('Przejmuje ticket na siebie').setDMPermission(false),
  new SlashCommandBuilder().setName('odprzejmij').setDescription('Zwalnia przejęty ticket').setDMPermission(false),
  new SlashCommandBuilder().setName('statystyki').setDescription('Pokazuje liczbę zamkniętych ticketów administracji').setDMPermission(false),
  new SlashCommandBuilder()
    .setName('wygeneruj_rep')
    .setDescription('Generuje wiadomość +rep do skopiowania')
    .setDMPermission(false)
    .addStringOption(opt => opt.setName('produkt').setDescription('Produkt z listy produktów').setRequired(true).setAutocomplete(true))
    .addUserOption(opt => opt.setName('sprzedawca').setDescription('Sprzedawca oznaczany w opinii +rep').setRequired(true))
    .addUserOption(opt => opt.setName('kupujacy').setDescription('Kupujący, który otrzyma wiadomość prywatną').setRequired(true)),
  new SlashCommandBuilder()
    .setName('dodaj_produkt')
    .setDescription('Dodaje produkt do listy +rep')
    .setDMPermission(false)
    .addStringOption(opt => opt.setName('nazwa').setDescription('Nazwa produktu').setRequired(true)),
  new SlashCommandBuilder()
    .setName('usun_produkt')
    .setDescription('Usuwa produkt z listy +rep')
    .setDMPermission(false)
    .addStringOption(opt => opt.setName('nazwa').setDescription('Nazwa produktu').setRequired(true)),
  new SlashCommandBuilder().setName('lista_produktow').setDescription('Pokazuje listę produktów +rep').setDMPermission(false),
  new SlashCommandBuilder()
    .setName('klient')
    .setDescription('Nadaje użytkownikowi rolę klienta')
    .setDMPermission(false)
    .addUserOption(opt => opt.setName('uzytkownik').setDescription('Użytkownik do oznaczenia jako klient').setRequired(true)),
  new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Usuwa określoną liczbę wiadomości z kanału')
    .setDMPermission(false)
    .addIntegerOption(opt => opt.setName('ilosc').setDescription('Liczba wiadomości do usunięcia').setRequired(true).setMinValue(1).setMaxValue(100)),
  new SlashCommandBuilder()
    .setName('massrole')
    .setDescription('Nadaje wybraną rolę wszystkim użytkownikom serwera')
    .setDMPermission(false)
    .addRoleOption(opt => opt.setName('rola').setDescription('Rola do nadania').setRequired(true)),
  new SlashCommandBuilder()
    .setName('embed')
    .setDescription('Wysyła embed na tym kanale')
    .setDMPermission(false)
    .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
    .addStringOption(opt => opt.setName('tytul').setDescription('Tytuł embeda').setRequired(true).setMaxLength(256))
    .addStringOption(opt => opt.setName('tresc').setDescription('Treść embeda').setRequired(true).setMaxLength(4000))
    .addStringOption(opt => opt.setName('kolor').setDescription('Kolor w formacie #RRGGBB').setMinLength(7).setMaxLength(7)),
  new SlashCommandBuilder()
    .setName('dmall')
    .setDescription('Wysyła wiadomość Components V2 do wszystkich członków serwera')
    .setDMPermission(false)
    .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator)
    .addStringOption(opt => opt.setName('tresc').setDescription('Treść wiadomości prywatnej').setRequired(true).setMaxLength(4000)),
  new SlashCommandBuilder()
    .setName('drop_standard')
    .setDescription('Drop standardowy')
    .setDMPermission(false),
  new SlashCommandBuilder()
    .setName('drop_premium')
    .setDescription('Drop premium')
    .setDMPermission(false)
].map(command => command.toJSON());

const rest = new REST({ version: '10' }).setToken(process.env.DISCORD_TOKEN);

client.once('clientReady', async () => {
  console.log(`🤖 Bot jest gotowy jako ${client.user.tag}`);

  for (const mod of modules) {
    if (mod.onClientReady) {
      try {
        mod.onClientReady(client);
      } catch (error) {
        console.error(`Błąd inicjalizacji modułu ${mod.name}:`, error);
      }
    }
  }

  try {
    await rest.put(
      Routes.applicationCommands(client.user.id),
      { body: commands }
    );
    console.log('✅ Komendy slash zostały pomyślnie zarejestrowane!');
  } catch (error) {
    console.error('❌ Błąd podczas rejestrowania komend:', error);
  }
});

registerAuditLogs(client);

client.on('presenceUpdate', (oldPresence, newPresence) => {
  statusModule.onPresenceUpdate(oldPresence, newPresence);
});

client.on('messageCreate', async (message) => {
  for (const mod of modules) {
    if (!mod.onMessageCreate) continue;

    try {
      await mod.onMessageCreate(message);
    } catch (err) {
      console.error(`Błąd obsługi wiadomości w module ${mod.name}:`, err);
    }
  }
});

client.on('interactionCreate', async (interaction) => {
  for (const mod of modules) {
    try {
      if (interaction.isChatInputCommand() && mod.onSlashCommandInteraction) {
        await mod.onSlashCommandInteraction(interaction);
      } else if (interaction.isButton() && mod.onButtonInteraction) {
        await mod.onButtonInteraction(interaction);
      } else if (interaction.isStringSelectMenu() && mod.onStringSelectInteraction) {
        await mod.onStringSelectInteraction(interaction);
      } else if (interaction.isModalSubmit() && mod.onModalInteraction) {
        await mod.onModalInteraction(interaction);
      } else if (interaction.isAutocomplete() && mod.onAutocompleteInteraction) {
        await mod.onAutocompleteInteraction(interaction);
        break;
      }
    } catch (err) {
      console.error(`Błąd w module ${mod.name}:`, err);
    }
  }
});

client.on('guildMemberAdd', async (member) => {
  for (const mod of modules) {
    if (mod.onGuildMemberAdd) await mod.onGuildMemberAdd(member);
  }
});

client.on('guildMemberRemove', (member) => {
  if (statusModule.onGuildMemberRemove) statusModule.onGuildMemberRemove(member);
});

client.login(process.env.DISCORD_TOKEN);
